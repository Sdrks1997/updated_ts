"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseConversationListItem = exports.MESSAGE_TEXT_CLASS_NAME = exports.DATE_CLASS_NAME = void 0;
const react_1 = __importDefault(require("react"));
const classnames_1 = __importDefault(require("classnames"));
const lodash_1 = require("lodash");
const Avatar_1 = require("../Avatar");
const Timestamp_1 = require("../conversation/Timestamp");
const isConversationUnread_1 = require("../../util/isConversationUnread");
const _util_1 = require("../_util");
const BASE_CLASS_NAME = 'module-conversation-list__item--contact-or-conversation';
const CONTENT_CLASS_NAME = `${BASE_CLASS_NAME}__content`;
const HEADER_CLASS_NAME = `${CONTENT_CLASS_NAME}__header`;
exports.DATE_CLASS_NAME = `${HEADER_CLASS_NAME}__date`;
const TIMESTAMP_CLASS_NAME = `${exports.DATE_CLASS_NAME}__timestamp`;
const MESSAGE_CLASS_NAME = `${CONTENT_CLASS_NAME}__message`;
exports.MESSAGE_TEXT_CLASS_NAME = `${MESSAGE_CLASS_NAME}__text`;
const CHECKBOX_CLASS_NAME = `${BASE_CLASS_NAME}__checkbox`;
exports.BaseConversationListItem = react_1.default.memo(({ acceptedMessageRequest, avatarPath, checked, color, conversationType, disabled, headerDate, headerName, i18n, id, isMe, isNoteToSelf, isSelected, markedUnread, messageStatusIcon, messageText, name, onClick, phoneNumber, profileName, sharedGroupNames, style, title, unblurredAvatarPath, unreadCount, }) => {
    const isUnread = isConversationUnread_1.isConversationUnread({ markedUnread, unreadCount });
    const isAvatarNoteToSelf = lodash_1.isBoolean(isNoteToSelf)
        ? isNoteToSelf
        : Boolean(isMe);
    const isCheckbox = lodash_1.isBoolean(checked);
    let checkboxNode;
    if (isCheckbox) {
        let ariaLabel;
        if (disabled) {
            ariaLabel = i18n('cannotSelectContact');
        }
        else if (checked) {
            ariaLabel = i18n('deselectContact');
        }
        else {
            ariaLabel = i18n('selectContact');
        }
        checkboxNode = (react_1.default.createElement("input", { "aria-label": ariaLabel, checked: checked, className: CHECKBOX_CLASS_NAME, disabled: disabled, onChange: onClick, onKeyDown: event => {
                if (onClick && !disabled && event.key === 'Enter') {
                    onClick();
                }
            }, type: "checkbox" }));
    }
    const contents = (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement("div", { className: `${BASE_CLASS_NAME}__avatar-container` },
            react_1.default.createElement(Avatar_1.Avatar, { acceptedMessageRequest: acceptedMessageRequest, avatarPath: avatarPath, color: color, conversationType: conversationType, noteToSelf: isAvatarNoteToSelf, i18n: i18n, isMe: isMe, name: name, phoneNumber: phoneNumber, profileName: profileName, title: title, sharedGroupNames: sharedGroupNames, size: Avatar_1.AvatarSize.FIFTY_TWO, unblurredAvatarPath: unblurredAvatarPath }),
            isUnread && (react_1.default.createElement("div", { className: `${BASE_CLASS_NAME}__unread-count` }, unreadCount || ''))),
        react_1.default.createElement("div", { className: classnames_1.default(CONTENT_CLASS_NAME, disabled && `${CONTENT_CLASS_NAME}--disabled`) },
            react_1.default.createElement("div", { className: HEADER_CLASS_NAME },
                react_1.default.createElement("div", { className: `${HEADER_CLASS_NAME}__name` }, headerName),
                lodash_1.isNumber(headerDate) && (react_1.default.createElement("div", { className: classnames_1.default(exports.DATE_CLASS_NAME, {
                        [`${exports.DATE_CLASS_NAME}--has-unread`]: isUnread,
                    }) },
                    react_1.default.createElement(Timestamp_1.Timestamp, { timestamp: headerDate, extended: false, module: TIMESTAMP_CLASS_NAME, withUnread: isUnread, i18n: i18n })))),
            messageText ? (react_1.default.createElement("div", { className: MESSAGE_CLASS_NAME },
                react_1.default.createElement("div", { dir: "auto", className: classnames_1.default(exports.MESSAGE_TEXT_CLASS_NAME, {
                        [`${exports.MESSAGE_TEXT_CLASS_NAME}--has-unread`]: isUnread,
                    }) }, messageText),
                messageStatusIcon)) : null),
        checkboxNode));
    const commonClassNames = classnames_1.default(BASE_CLASS_NAME, {
        [`${BASE_CLASS_NAME}--has-unread`]: isUnread,
        [`${BASE_CLASS_NAME}--is-selected`]: isSelected,
    });
    if (isCheckbox) {
        return (react_1.default.createElement("label", Object.assign({ className: classnames_1.default(commonClassNames, `${BASE_CLASS_NAME}--is-checkbox`, { [`${BASE_CLASS_NAME}--is-checkbox--disabled`]: disabled }), "data-id": id ? _util_1.cleanId(id) : undefined, style: style }, (disabled ? { onClick } : {})), contents));
    }
    if (onClick) {
        return (react_1.default.createElement("button", { className: classnames_1.default(commonClassNames, `${BASE_CLASS_NAME}--is-button`), "data-id": id ? _util_1.cleanId(id) : undefined, disabled: disabled, onClick: onClick, style: style, type: "button" }, contents));
    }
    return (react_1.default.createElement("div", { className: commonClassNames, "data-id": id ? _util_1.cleanId(id) : undefined, style: style }, contents));
});
