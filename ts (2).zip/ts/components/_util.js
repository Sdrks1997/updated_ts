"use strict";
// Copyright 2019-2020 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRefMerger = exports.cleanId = void 0;
const lodash_1 = require("lodash");
const memoizee_1 = __importDefault(require("memoizee"));
function cleanId(id) {
    return id.replace(/[^\u0020-\u007e\u00a0-\u00ff]/g, '_');
}
exports.cleanId = cleanId;
// Memoizee makes this difficult.
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
const createRefMerger = () => memoizee_1.default((...refs) => {
    return (t) => {
        refs.forEach(r => {
            if (lodash_1.isFunction(r)) {
                r(t);
            }
            else if (r) {
                // Using a MutableRefObject as intended
                // eslint-disable-next-line no-param-reassign
                r.current = t;
            }
        });
    };
}, { length: false, max: 1 });
exports.createRefMerger = createRefMerger;
