"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const react_1 = require("@storybook/react");
const addon_actions_1 = require("@storybook/addon-actions");
const Fixtures_1 = require("../storybook/Fixtures");
const i18n_1 = require("../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../_locales/en/messages.json"));
const ContactListItem_1 = require("./ContactListItem");
const i18n = i18n_1.setup('en', messages_json_1.default);
const onClick = addon_actions_1.action('onClick');
react_1.storiesOf('Components/ContactListItem', module)
    .add("It's me!", () => {
    return (React.createElement(ContactListItem_1.ContactListItem, { type: "direct", acceptedMessageRequest: true, i18n: i18n, isMe: true, title: "Someone \uD83D\uDD25 Somewhere", name: "Someone \uD83D\uDD25 Somewhere", phoneNumber: "(202) 555-0011", profileName: "\uD83D\uDD25Flames\uD83D\uDD25", sharedGroupNames: [], avatarPath: Fixtures_1.gifUrl, onClick: onClick }));
})
    .add('With name and profile (note vertical spacing)', () => {
    return (React.createElement("div", null,
        React.createElement(ContactListItem_1.ContactListItem, { type: "direct", acceptedMessageRequest: true, i18n: i18n, isMe: false, title: "Someone \uD83D\uDD25 Somewhere", name: "Someone \uD83D\uDD25 Somewhere", phoneNumber: "(202) 555-0011", profileName: "\uD83D\uDD25Flames\uD83D\uDD25", sharedGroupNames: [], about: "\uD83D\uDC4D Free to chat", avatarPath: Fixtures_1.gifUrl, onClick: onClick }),
        React.createElement(ContactListItem_1.ContactListItem, { type: "direct", acceptedMessageRequest: true, i18n: i18n, isMe: false, title: "Another \u2744\uFE0F Yes", name: "Another \u2744\uFE0F Yes", phoneNumber: "(202) 555-0011", profileName: "\u2744\uFE0FIce\u2744\uFE0F", sharedGroupNames: [], about: "\uD83D\uDE4F Be kind", avatarPath: Fixtures_1.gifUrl, onClick: onClick })));
})
    .add('With name and profile, admin', () => {
    return (React.createElement(ContactListItem_1.ContactListItem, { type: "direct", acceptedMessageRequest: true, i18n: i18n, isMe: false, isAdmin: true, title: "Someone \uD83D\uDD25 Somewhere", name: "Someone \uD83D\uDD25 Somewhere", phoneNumber: "(202) 555-0011", profileName: "\uD83D\uDD25Flames\uD83D\uDD25", sharedGroupNames: [], about: "\uD83D\uDC4D This is my really long status message that I have in order to test line breaking", avatarPath: Fixtures_1.gifUrl, onClick: onClick }));
})
    .add('With a group with no avatarPath', () => {
    return (React.createElement(ContactListItem_1.ContactListItem, { type: "group", i18n: i18n, isMe: false, isAdmin: true, title: "Group!", sharedGroupNames: [], acceptedMessageRequest: true, about: "\uD83D\uDC4D Free to chat", onClick: onClick }));
})
    .add('With just number, admin', () => {
    return (React.createElement(ContactListItem_1.ContactListItem, { type: "direct", acceptedMessageRequest: true, i18n: i18n, isMe: false, isAdmin: true, title: "(202) 555-0011", phoneNumber: "(202) 555-0011", sharedGroupNames: [], about: "\uD83D\uDC4D Free to chat", avatarPath: Fixtures_1.gifUrl, onClick: onClick }));
})
    .add('With name and profile, no avatar', () => {
    return (React.createElement(ContactListItem_1.ContactListItem, { type: "direct", acceptedMessageRequest: true, i18n: i18n, isMe: false, title: "Someone \uD83D\uDD25 Somewhere", name: "Someone \uD83D\uDD25 Somewhere", color: "teal", phoneNumber: "(202) 555-0011", profileName: "\uD83D\uDD25Flames\uD83D\uDD25", sharedGroupNames: [], about: "\uD83D\uDC4D Free to chat", onClick: onClick }));
})
    .add('Profile, no name, no avatar', () => {
    return (React.createElement(ContactListItem_1.ContactListItem, { type: "direct", acceptedMessageRequest: true, color: "blue", i18n: i18n, isMe: false, phoneNumber: "(202) 555-0011", title: "\uD83D\uDD25Flames\uD83D\uDD25", profileName: "\uD83D\uDD25Flames\uD83D\uDD25", sharedGroupNames: [], about: "\uD83D\uDC4D Free to chat", onClick: onClick }));
})
    .add('No name, no profile, no avatar, no about', () => {
    return (React.createElement(ContactListItem_1.ContactListItem, { type: "direct", acceptedMessageRequest: true, i18n: i18n, isMe: false, phoneNumber: "(202) 555-0011", sharedGroupNames: [], title: "(202) 555-0011", onClick: onClick }));
})
    .add('No name, no profile, no avatar', () => {
    return (React.createElement(ContactListItem_1.ContactListItem, { type: "direct", acceptedMessageRequest: true, i18n: i18n, isMe: false, title: "(202) 555-0011", about: "\uD83D\uDC4D Free to chat", sharedGroupNames: [], phoneNumber: "(202) 555-0011", onClick: onClick }));
})
    .add('No name, no profile, no number', () => {
    return (React.createElement(ContactListItem_1.ContactListItem, { type: "direct", acceptedMessageRequest: true, i18n: i18n, isMe: false, title: "Unknown contact", sharedGroupNames: [], onClick: onClick }));
});
