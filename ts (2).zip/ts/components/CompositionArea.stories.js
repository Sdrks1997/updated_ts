"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const react_1 = require("@storybook/react");
const addon_actions_1 = require("@storybook/addon-actions");
const addon_knobs_1 = require("@storybook/addon-knobs");
const CompositionArea_1 = require("./CompositionArea");
const i18n_1 = require("../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../_locales/en/messages.json"));
const i18n = i18n_1.setup('en', messages_json_1.default);
const story = react_1.storiesOf('Components/CompositionArea', module);
// necessary for the add attachment button to render properly
story.addDecorator(storyFn => React.createElement("div", { className: "file-input" }, storyFn()));
// necessary for the mic button to render properly
const micCellEl = new DOMParser().parseFromString(`
    <div class="capture-audio">
      <button class="microphone"></button>
    </div>
  `, 'text/html').body.firstElementChild;
const createProps = (overrideProps = {}) => ({
    i18n,
    micCellEl,
    onChooseAttachment: addon_actions_1.action('onChooseAttachment'),
    // CompositionInput
    onSubmit: addon_actions_1.action('onSubmit'),
    onEditorStateChange: addon_actions_1.action('onEditorStateChange'),
    onTextTooLong: addon_actions_1.action('onTextTooLong'),
    draftText: overrideProps.draftText || undefined,
    clearQuotedMessage: addon_actions_1.action('clearQuotedMessage'),
    getQuotedMessage: addon_actions_1.action('getQuotedMessage'),
    sortedGroupMembers: [],
    // EmojiButton
    onPickEmoji: addon_actions_1.action('onPickEmoji'),
    onSetSkinTone: addon_actions_1.action('onSetSkinTone'),
    recentEmojis: [],
    skinTone: 1,
    // StickerButton
    knownPacks: overrideProps.knownPacks || [],
    receivedPacks: [],
    installedPacks: [],
    blessedPacks: [],
    recentStickers: [],
    clearInstalledStickerPack: addon_actions_1.action('clearInstalledStickerPack'),
    onClickAddPack: addon_actions_1.action('onClickAddPack'),
    onPickSticker: addon_actions_1.action('onPickSticker'),
    clearShowIntroduction: addon_actions_1.action('clearShowIntroduction'),
    showPickerHint: false,
    clearShowPickerHint: addon_actions_1.action('clearShowPickerHint'),
    // Message Requests
    conversationType: 'direct',
    onAccept: addon_actions_1.action('onAccept'),
    onBlock: addon_actions_1.action('onBlock'),
    onBlockAndReportSpam: addon_actions_1.action('onBlockAndReportSpam'),
    onDelete: addon_actions_1.action('onDelete'),
    onUnblock: addon_actions_1.action('onUnblock'),
    messageRequestsEnabled: addon_knobs_1.boolean('messageRequestsEnabled', overrideProps.messageRequestsEnabled || false),
    title: '',
    // GroupV1 Disabled Actions
    onStartGroupMigration: addon_actions_1.action('onStartGroupMigration'),
    // GroupV2 Pending Approval Actions
    onCancelJoinRequest: addon_actions_1.action('onCancelJoinRequest'),
    // SMS-only
    isSMSOnly: overrideProps.isSMSOnly || false,
    isFetchingUUID: overrideProps.isFetchingUUID || false,
});
story.add('Default', () => {
    const props = createProps();
    return React.createElement(CompositionArea_1.CompositionArea, Object.assign({}, props));
});
story.add('Starting Text', () => {
    const props = createProps({
        draftText: "here's some starting text",
    });
    return React.createElement(CompositionArea_1.CompositionArea, Object.assign({}, props));
});
story.add('Sticker Button', () => {
    const props = createProps({
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        knownPacks: [{}],
    });
    return React.createElement(CompositionArea_1.CompositionArea, Object.assign({}, props));
});
story.add('Message Request', () => {
    const props = createProps({
        messageRequestsEnabled: true,
    });
    return React.createElement(CompositionArea_1.CompositionArea, Object.assign({}, props));
});
story.add('SMS-only fetching UUID', () => {
    const props = createProps({
        isSMSOnly: true,
        isFetchingUUID: true,
    });
    return React.createElement(CompositionArea_1.CompositionArea, Object.assign({}, props));
});
story.add('SMS-only', () => {
    const props = createProps({
        isSMSOnly: true,
    });
    return React.createElement(CompositionArea_1.CompositionArea, Object.assign({}, props));
});
