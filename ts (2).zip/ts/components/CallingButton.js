"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CallingButton = exports.CallingButtonType = void 0;
const react_1 = __importDefault(require("react"));
const classnames_1 = __importDefault(require("classnames"));
const Tooltip_1 = require("./Tooltip");
const theme_1 = require("../util/theme");
var CallingButtonType;
(function (CallingButtonType) {
    CallingButtonType["AUDIO_DISABLED"] = "AUDIO_DISABLED";
    CallingButtonType["AUDIO_OFF"] = "AUDIO_OFF";
    CallingButtonType["AUDIO_ON"] = "AUDIO_ON";
    CallingButtonType["HANG_UP"] = "HANG_UP";
    CallingButtonType["PRESENTING_DISABLED"] = "PRESENTING_DISABLED";
    CallingButtonType["PRESENTING_OFF"] = "PRESENTING_OFF";
    CallingButtonType["PRESENTING_ON"] = "PRESENTING_ON";
    CallingButtonType["VIDEO_DISABLED"] = "VIDEO_DISABLED";
    CallingButtonType["VIDEO_OFF"] = "VIDEO_OFF";
    CallingButtonType["VIDEO_ON"] = "VIDEO_ON";
})(CallingButtonType = exports.CallingButtonType || (exports.CallingButtonType = {}));
const CallingButton = ({ buttonType, i18n, onClick, tooltipDirection, }) => {
    let classNameSuffix = '';
    let tooltipContent = '';
    let disabled = false;
    if (buttonType === CallingButtonType.AUDIO_DISABLED) {
        classNameSuffix = 'audio--disabled';
        tooltipContent = i18n('calling__button--audio-disabled');
        disabled = true;
    }
    else if (buttonType === CallingButtonType.AUDIO_OFF) {
        classNameSuffix = 'audio--off';
        tooltipContent = i18n('calling__button--audio-on');
    }
    else if (buttonType === CallingButtonType.AUDIO_ON) {
        classNameSuffix = 'audio--on';
        tooltipContent = i18n('calling__button--audio-off');
    }
    else if (buttonType === CallingButtonType.VIDEO_DISABLED) {
        classNameSuffix = 'video--disabled';
        tooltipContent = i18n('calling__button--video-disabled');
        disabled = true;
    }
    else if (buttonType === CallingButtonType.VIDEO_OFF) {
        classNameSuffix = 'video--off';
        tooltipContent = i18n('calling__button--video-on');
    }
    else if (buttonType === CallingButtonType.VIDEO_ON) {
        classNameSuffix = 'video--on';
        tooltipContent = i18n('calling__button--video-off');
    }
    else if (buttonType === CallingButtonType.HANG_UP) {
        classNameSuffix = 'hangup';
        tooltipContent = i18n('calling__hangup');
    }
    else if (buttonType === CallingButtonType.PRESENTING_DISABLED) {
        classNameSuffix = 'presenting--disabled';
        tooltipContent = i18n('calling__button--presenting-disabled');
        disabled = true;
    }
    else if (buttonType === CallingButtonType.PRESENTING_ON) {
        classNameSuffix = 'presenting--on';
        tooltipContent = i18n('calling__button--presenting-off');
    }
    else if (buttonType === CallingButtonType.PRESENTING_OFF) {
        classNameSuffix = 'presenting--off';
        tooltipContent = i18n('calling__button--presenting-on');
    }
    const className = classnames_1.default('module-calling-button__icon', `module-calling-button__icon--${classNameSuffix}`);
    return (react_1.default.createElement(Tooltip_1.Tooltip, { content: tooltipContent, direction: tooltipDirection, theme: theme_1.Theme.Dark },
        react_1.default.createElement("button", { "aria-label": tooltipContent, className: className, disabled: disabled, onClick: onClick, type: "button" },
            react_1.default.createElement("div", null))));
};
exports.CallingButton = CallingButton;
