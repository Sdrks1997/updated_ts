"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const react_1 = require("@storybook/react");
const addon_actions_1 = require("@storybook/addon-actions");
const addon_knobs_1 = require("@storybook/addon-knobs");
const CallManager_1 = require("./CallManager");
const Calling_1 = require("../types/Calling");
const Colors_1 = require("../types/Colors");
const getDefaultConversation_1 = require("../test-both/helpers/getDefaultConversation");
const fakeGetGroupCallVideoFrameSource_1 = require("../test-both/helpers/fakeGetGroupCallVideoFrameSource");
const i18n_1 = require("../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../_locales/en/messages.json"));
const i18n = i18n_1.setup('en', messages_json_1.default);
const getConversation = () => getDefaultConversation_1.getDefaultConversation({
    id: '3051234567',
    avatarPath: undefined,
    color: addon_knobs_1.select('Callee color', Colors_1.AvatarColors, 'ultramarine'),
    title: addon_knobs_1.text('Callee Title', 'Rick Sanchez'),
    name: addon_knobs_1.text('Callee Name', 'Rick Sanchez'),
    phoneNumber: '3051234567',
    profileName: 'Rick Sanchez',
    markedUnread: false,
    type: 'direct',
    lastUpdated: Date.now(),
});
const getCommonActiveCallData = () => ({
    conversation: getConversation(),
    joinedAt: Date.now(),
    hasLocalAudio: addon_knobs_1.boolean('hasLocalAudio', true),
    hasLocalVideo: addon_knobs_1.boolean('hasLocalVideo', false),
    isInSpeakerView: addon_knobs_1.boolean('isInSpeakerView', false),
    pip: addon_knobs_1.boolean('pip', false),
    settingsDialogOpen: addon_knobs_1.boolean('settingsDialogOpen', false),
    showParticipantsList: addon_knobs_1.boolean('showParticipantsList', false),
});
const getIncomingCallState = (extraProps = {}) => (Object.assign(Object.assign({}, extraProps), { callMode: Calling_1.CallMode.Direct, conversationId: '3051234567', callState: Calling_1.CallState.Ringing, isIncoming: true, isVideoCall: addon_knobs_1.boolean('isVideoCall', true), hasRemoteVideo: true }));
const createProps = (storyProps = {}) => (Object.assign(Object.assign({}, storyProps), { availableCameras: [], acceptCall: addon_actions_1.action('accept-call'), cancelCall: addon_actions_1.action('cancel-call'), closeNeedPermissionScreen: addon_actions_1.action('close-need-permission-screen'), declineCall: addon_actions_1.action('decline-call'), getGroupCallVideoFrameSource: (_, demuxId) => fakeGetGroupCallVideoFrameSource_1.fakeGetGroupCallVideoFrameSource(demuxId), getPresentingSources: addon_actions_1.action('get-presenting-sources'), hangUp: addon_actions_1.action('hang-up'), i18n, keyChangeOk: addon_actions_1.action('key-change-ok'), me: Object.assign(Object.assign({}, getDefaultConversation_1.getDefaultConversation({
        color: addon_knobs_1.select('Caller color', Colors_1.AvatarColors, 'ultramarine'),
        title: addon_knobs_1.text('Caller Title', 'Morty Smith'),
    })), { uuid: 'cb0dd0c8-7393-41e9-a0aa-d631c4109541' }), openSystemPreferencesAction: addon_actions_1.action('open-system-preferences-action'), renderDeviceSelection: () => React.createElement("div", null), renderSafetyNumberViewer: (_) => React.createElement("div", null), setGroupCallVideoRequest: addon_actions_1.action('set-group-call-video-request'), setLocalAudio: addon_actions_1.action('set-local-audio'), setLocalPreview: addon_actions_1.action('set-local-preview'), setLocalVideo: addon_actions_1.action('set-local-video'), setPresenting: addon_actions_1.action('toggle-presenting'), setRendererCanvas: addon_actions_1.action('set-renderer-canvas'), startCall: addon_actions_1.action('start-call'), toggleParticipants: addon_actions_1.action('toggle-participants'), togglePip: addon_actions_1.action('toggle-pip'), toggleScreenRecordingPermissionsDialog: addon_actions_1.action('toggle-screen-recording-permissions-dialog'), toggleSettings: addon_actions_1.action('toggle-settings'), toggleSpeakerView: addon_actions_1.action('toggle-speaker-view') }));
const story = react_1.storiesOf('Components/CallManager', module);
story.add('No Call', () => React.createElement(CallManager_1.CallManager, Object.assign({}, createProps())));
story.add('Ongoing Direct Call', () => (React.createElement(CallManager_1.CallManager, Object.assign({}, createProps({
    activeCall: Object.assign(Object.assign({}, getCommonActiveCallData()), { callMode: Calling_1.CallMode.Direct, callState: Calling_1.CallState.Accepted, peekedParticipants: [], remoteParticipants: [
            { hasRemoteVideo: true, presenting: false, title: 'Remy' },
        ] }),
})))));
story.add('Ongoing Group Call', () => (React.createElement(CallManager_1.CallManager, Object.assign({}, createProps({
    activeCall: Object.assign(Object.assign({}, getCommonActiveCallData()), { callMode: Calling_1.CallMode.Group, connectionState: Calling_1.GroupCallConnectionState.Connected, conversationsWithSafetyNumberChanges: [], deviceCount: 0, joinState: Calling_1.GroupCallJoinState.Joined, maxDevices: 5, peekedParticipants: [], remoteParticipants: [] }),
})))));
story.add('Ringing', () => (React.createElement(CallManager_1.CallManager, Object.assign({}, createProps({
    incomingCall: {
        call: getIncomingCallState(),
        conversation: getConversation(),
    },
})))));
story.add('Call Request Needed', () => (React.createElement(CallManager_1.CallManager, Object.assign({}, createProps({
    activeCall: Object.assign(Object.assign({}, getCommonActiveCallData()), { callEndedReason: Calling_1.CallEndedReason.RemoteHangupNeedPermission, callMode: Calling_1.CallMode.Direct, callState: Calling_1.CallState.Accepted, peekedParticipants: [], remoteParticipants: [
            { hasRemoteVideo: true, presenting: false, title: 'Mike' },
        ] }),
})))));
story.add('Group call - Safety Number Changed', () => (React.createElement(CallManager_1.CallManager, Object.assign({}, createProps({
    activeCall: Object.assign(Object.assign({}, getCommonActiveCallData()), { callMode: Calling_1.CallMode.Group, connectionState: Calling_1.GroupCallConnectionState.Connected, conversationsWithSafetyNumberChanges: [
            Object.assign({}, getDefaultConversation_1.getDefaultConversation({
                title: 'Aaron',
            })),
        ], deviceCount: 0, joinState: Calling_1.GroupCallJoinState.Joined, maxDevices: 5, peekedParticipants: [], remoteParticipants: [] }),
})))));
