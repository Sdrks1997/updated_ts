"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importDefault(require("react"));
const react_2 = require("@storybook/react");
const addon_actions_1 = require("@storybook/addon-actions");
const Button_1 = require("./Button");
const story = react_2.storiesOf('Components/Button', module);
story.add('Kitchen sink', () => (react_1.default.createElement(react_1.default.Fragment, null, [Button_1.ButtonSize.Medium, Button_1.ButtonSize.Small].map(size => (react_1.default.createElement(react_1.default.Fragment, { key: size }, [
    Button_1.ButtonVariant.Primary,
    Button_1.ButtonVariant.Secondary,
    Button_1.ButtonVariant.SecondaryAffirmative,
    Button_1.ButtonVariant.SecondaryDestructive,
    Button_1.ButtonVariant.Destructive,
].map(variant => (react_1.default.createElement(react_1.default.Fragment, { key: variant },
    react_1.default.createElement("p", null,
        react_1.default.createElement(Button_1.Button, { onClick: addon_actions_1.action('onClick'), size: size, variant: variant }, "Hello world")),
    react_1.default.createElement("p", null,
        react_1.default.createElement(Button_1.Button, { disabled: true, onClick: addon_actions_1.action('onClick'), size: size, variant: variant }, "Hello world")))))))))));
story.add('aria-label', () => (react_1.default.createElement(Button_1.Button, { "aria-label": "hello", className: "module-ForwardMessageModal__header--back", onClick: addon_actions_1.action('onClick') })));
