"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Button = exports.ButtonVariant = exports.ButtonSize = void 0;
const react_1 = __importDefault(require("react"));
const classnames_1 = __importDefault(require("classnames"));
const assert_1 = require("../util/assert");
var ButtonSize;
(function (ButtonSize) {
    ButtonSize[ButtonSize["Medium"] = 0] = "Medium";
    ButtonSize[ButtonSize["Small"] = 1] = "Small";
})(ButtonSize = exports.ButtonSize || (exports.ButtonSize = {}));
var ButtonVariant;
(function (ButtonVariant) {
    ButtonVariant[ButtonVariant["Primary"] = 0] = "Primary";
    ButtonVariant[ButtonVariant["Secondary"] = 1] = "Secondary";
    ButtonVariant[ButtonVariant["SecondaryAffirmative"] = 2] = "SecondaryAffirmative";
    ButtonVariant[ButtonVariant["SecondaryDestructive"] = 3] = "SecondaryDestructive";
    ButtonVariant[ButtonVariant["Destructive"] = 4] = "Destructive";
})(ButtonVariant = exports.ButtonVariant || (exports.ButtonVariant = {}));
const SIZE_CLASS_NAMES = new Map([
    [ButtonSize.Medium, 'module-Button--medium'],
    [ButtonSize.Small, 'module-Button--small'],
]);
const VARIANT_CLASS_NAMES = new Map([
    [ButtonVariant.Primary, 'module-Button--primary'],
    [ButtonVariant.Secondary, 'module-Button--secondary'],
    [
        ButtonVariant.SecondaryAffirmative,
        'module-Button--secondary module-Button--secondary--affirmative',
    ],
    [
        ButtonVariant.SecondaryDestructive,
        'module-Button--secondary module-Button--secondary--destructive',
    ],
    [ButtonVariant.Destructive, 'module-Button--destructive'],
]);
exports.Button = react_1.default.forwardRef((props, ref) => {
    const { children, className, disabled = false, size = ButtonSize.Medium, variant = ButtonVariant.Primary, } = props;
    const ariaLabel = props['aria-label'];
    let onClick;
    let type;
    if ('onClick' in props) {
        ({ onClick } = props);
        type = 'button';
    }
    else {
        onClick = undefined;
        ({ type } = props);
    }
    const sizeClassName = SIZE_CLASS_NAMES.get(size);
    assert_1.assert(sizeClassName, '<Button> size not found');
    const variantClassName = VARIANT_CLASS_NAMES.get(variant);
    assert_1.assert(variantClassName, '<Button> variant not found');
    return (react_1.default.createElement("button", { "aria-label": ariaLabel, className: classnames_1.default('module-Button', sizeClassName, variantClassName, className), disabled: disabled, onClick: onClick, ref: ref, 
        // The `type` should either be "button" or "submit", which is effectively static.
        // eslint-disable-next-line react/button-has-type
        type: type }, children));
});
