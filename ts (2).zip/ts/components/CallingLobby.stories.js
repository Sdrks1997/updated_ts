"use strict";
// Copyright 2020 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const react_1 = require("@storybook/react");
const addon_knobs_1 = require("@storybook/addon-knobs");
const addon_actions_1 = require("@storybook/addon-actions");
const uuid_1 = require("uuid");
const Colors_1 = require("../types/Colors");
const CallingLobby_1 = require("./CallingLobby");
const i18n_1 = require("../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../_locales/en/messages.json"));
const getDefaultConversation_1 = require("../test-both/helpers/getDefaultConversation");
const i18n = i18n_1.setup('en', messages_json_1.default);
const camera = {
    deviceId: 'dfbe6effe70b0611ba0fdc2a9ea3f39f6cb110e6687948f7e5f016c111b7329c',
    groupId: '63ee218d2446869e40adfc958ff98263e51f74382b0143328ee4826f20a76f47',
    kind: 'videoinput',
    label: 'FaceTime HD Camera (Built-in) (9fba:bced)',
    toJSON() {
        return '';
    },
};
const createProps = (overrideProps = {}) => ({
    availableCameras: overrideProps.availableCameras || [camera],
    conversation: {
        title: 'Rick Sanchez',
    },
    hasLocalAudio: addon_knobs_1.boolean('hasLocalAudio', overrideProps.hasLocalAudio || false),
    hasLocalVideo: addon_knobs_1.boolean('hasLocalVideo', overrideProps.hasLocalVideo || false),
    i18n,
    isGroupCall: addon_knobs_1.boolean('isGroupCall', overrideProps.isGroupCall || false),
    isCallFull: addon_knobs_1.boolean('isCallFull', overrideProps.isCallFull || false),
    me: overrideProps.me || {
        color: Colors_1.AvatarColors[0],
        uuid: uuid_1.v4(),
    },
    onCallCanceled: addon_actions_1.action('on-call-canceled'),
    onJoinCall: addon_actions_1.action('on-join-call'),
    peekedParticipants: overrideProps.peekedParticipants || [],
    setLocalAudio: addon_actions_1.action('set-local-audio'),
    setLocalPreview: addon_actions_1.action('set-local-preview'),
    setLocalVideo: addon_actions_1.action('set-local-video'),
    showParticipantsList: addon_knobs_1.boolean('showParticipantsList', Boolean(overrideProps.showParticipantsList)),
    toggleParticipants: addon_actions_1.action('toggle-participants'),
    toggleSettings: addon_actions_1.action('toggle-settings'),
});
const fakePeekedParticipant = (conversationProps) => getDefaultConversation_1.getDefaultConversation(Object.assign({ uuid: uuid_1.v4() }, conversationProps));
const story = react_1.storiesOf('Components/CallingLobby', module);
story.add('Default', () => {
    const props = createProps();
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('No Camera, no avatar', () => {
    const props = createProps({
        availableCameras: [],
    });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('No Camera, local avatar', () => {
    const props = createProps({
        availableCameras: [],
        me: {
            avatarPath: '/fixtures/kitten-4-112-112.jpg',
            color: Colors_1.AvatarColors[0],
            uuid: uuid_1.v4(),
        },
    });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('Local Video', () => {
    const props = createProps({
        hasLocalVideo: true,
    });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('Local Video', () => {
    const props = createProps({
        hasLocalVideo: true,
    });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('Group Call - 0 peeked participants', () => {
    const props = createProps({ isGroupCall: true, peekedParticipants: [] });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('Group Call - 1 peeked participant', () => {
    const props = createProps({
        isGroupCall: true,
        peekedParticipants: [{ title: 'Sam' }].map(fakePeekedParticipant),
    });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('Group Call - 1 peeked participant (self)', () => {
    const uuid = uuid_1.v4();
    const props = createProps({
        isGroupCall: true,
        me: { uuid },
        peekedParticipants: [fakePeekedParticipant({ title: 'Ash', uuid })],
    });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('Group Call - 2 peeked participants', () => {
    const props = createProps({
        isGroupCall: true,
        peekedParticipants: ['Sam', 'Cayce'].map(title => fakePeekedParticipant({ title })),
    });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('Group Call - 3 peeked participants', () => {
    const props = createProps({
        isGroupCall: true,
        peekedParticipants: ['Sam', 'Cayce', 'April'].map(title => fakePeekedParticipant({ title })),
    });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('Group Call - 4 peeked participants', () => {
    const props = createProps({
        isGroupCall: true,
        peekedParticipants: ['Sam', 'Cayce', 'April', 'Logan', 'Carl'].map(title => fakePeekedParticipant({ title })),
    });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('Group Call - 4 peeked participants (participants list)', () => {
    const props = createProps({
        isGroupCall: true,
        peekedParticipants: ['Sam', 'Cayce', 'April', 'Logan', 'Carl'].map(title => fakePeekedParticipant({ title })),
        showParticipantsList: true,
    });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
story.add('Group Call - call full', () => {
    const props = createProps({
        isGroupCall: true,
        isCallFull: true,
        peekedParticipants: ['Sam', 'Cayce'].map(title => fakePeekedParticipant({ title })),
    });
    return React.createElement(CallingLobby_1.CallingLobby, Object.assign({}, props));
});
