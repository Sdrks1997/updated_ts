"use strict";
// Copyright 2019-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfirmationDialog = void 0;
const React = __importStar(require("react"));
const Button_1 = require("./Button");
const Modal_1 = require("./Modal");
function focusRef(el) {
    if (el) {
        el.focus();
    }
}
function getButtonVariant(buttonStyle) {
    if (buttonStyle === 'affirmative') {
        return Button_1.ButtonVariant.Primary;
    }
    if (buttonStyle === 'negative') {
        return Button_1.ButtonVariant.Destructive;
    }
    return Button_1.ButtonVariant.Secondary;
}
exports.ConfirmationDialog = React.memo(({ moduleClassName, actions = [], cancelText, children, i18n, onCancel, onClose, theme, title, hasXButton, }) => {
    const cancelAndClose = React.useCallback(() => {
        if (onCancel) {
            onCancel();
        }
        onClose();
    }, [onCancel, onClose]);
    const handleCancel = React.useCallback((e) => {
        if (e.target === e.currentTarget) {
            cancelAndClose();
        }
    }, [cancelAndClose]);
    const hasActions = Boolean(actions.length);
    return (React.createElement(Modal_1.Modal, { moduleClassName: moduleClassName, i18n: i18n, onClose: cancelAndClose, title: title, theme: theme, hasXButton: hasXButton },
        children,
        React.createElement(Modal_1.Modal.ButtonFooter, null,
            React.createElement(Button_1.Button, { onClick: handleCancel, ref: focusRef, variant: hasActions ? Button_1.ButtonVariant.Secondary : Button_1.ButtonVariant.Primary }, cancelText || i18n('confirmation-dialog--Cancel')),
            actions.map((action, i) => (React.createElement(Button_1.Button, { key: action.text, onClick: () => {
                    action.action();
                    onClose();
                }, "data-action": i, variant: getButtonVariant(action.style) }, action.text))))));
});
