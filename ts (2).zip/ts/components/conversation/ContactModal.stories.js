"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const addon_actions_1 = require("@storybook/addon-actions");
const addon_knobs_1 = require("@storybook/addon-knobs");
const react_1 = require("@storybook/react");
const getDefaultConversation_1 = require("../../test-both/helpers/getDefaultConversation");
const ContactModal_1 = require("./ContactModal");
const i18n_1 = require("../../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../../_locales/en/messages.json"));
const i18n = i18n_1.setup('en', messages_json_1.default);
const story = react_1.storiesOf('Components/Conversation/ContactModal', module);
const defaultContact = getDefaultConversation_1.getDefaultConversation({
    id: 'abcdef',
    areWeAdmin: false,
    title: 'Pauline Oliveros',
    phoneNumber: '(333) 444-5515',
    about: '👍 Free to chat',
});
const createProps = (overrideProps = {}) => ({
    areWeAdmin: addon_knobs_1.boolean('areWeAdmin', overrideProps.areWeAdmin || false),
    contact: overrideProps.contact || defaultContact,
    i18n,
    isAdmin: addon_knobs_1.boolean('isAdmin', overrideProps.isAdmin || false),
    isMember: addon_knobs_1.boolean('isMember', overrideProps.isMember || true),
    onClose: addon_actions_1.action('onClose'),
    openConversation: addon_actions_1.action('openConversation'),
    removeMember: addon_actions_1.action('removeMember'),
    showSafetyNumber: addon_actions_1.action('showSafetyNumber'),
    toggleAdmin: addon_actions_1.action('toggleAdmin'),
    updateSharedGroups: addon_actions_1.action('updateSharedGroups'),
});
story.add('As non-admin', () => {
    const props = createProps({
        areWeAdmin: false,
    });
    return React.createElement(ContactModal_1.ContactModal, Object.assign({}, props));
});
story.add('As admin', () => {
    const props = createProps({
        areWeAdmin: true,
    });
    return React.createElement(ContactModal_1.ContactModal, Object.assign({}, props));
});
story.add('As admin, viewing non-member of group', () => {
    const props = createProps({
        isMember: false,
    });
    return React.createElement(ContactModal_1.ContactModal, Object.assign({}, props));
});
story.add('Without phone number', () => {
    const props = createProps({
        contact: Object.assign(Object.assign({}, defaultContact), { phoneNumber: undefined }),
    });
    return React.createElement(ContactModal_1.ContactModal, Object.assign({}, props));
});
story.add('Viewing self', () => {
    const props = createProps({
        contact: Object.assign(Object.assign({}, defaultContact), { isMe: true }),
    });
    return React.createElement(ContactModal_1.ContactModal, Object.assign({}, props));
});
