"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationDetails = void 0;
const react_1 = __importStar(require("react"));
const assert_1 = require("../../../util/assert");
const expirationTimer = __importStar(require("../../../util/expirationTimer"));
const missingCaseError_1 = require("../../../util/missingCaseError");
const Select_1 = require("../../Select");
const DisappearingTimeDialog_1 = require("../DisappearingTimeDialog");
const PanelRow_1 = require("./PanelRow");
const PanelSection_1 = require("./PanelSection");
const AddGroupMembersModal_1 = require("./AddGroupMembersModal");
const ConversationDetailsActions_1 = require("./ConversationDetailsActions");
const ConversationDetailsHeader_1 = require("./ConversationDetailsHeader");
const ConversationDetailsIcon_1 = require("./ConversationDetailsIcon");
const ConversationDetailsMediaList_1 = require("./ConversationDetailsMediaList");
const ConversationDetailsMembershipList_1 = require("./ConversationDetailsMembershipList");
const EditConversationAttributesModal_1 = require("./EditConversationAttributesModal");
const util_1 = require("./util");
const getCustomColorStyle_1 = require("../../../util/getCustomColorStyle");
var ModalState;
(function (ModalState) {
    ModalState[ModalState["NothingOpen"] = 0] = "NothingOpen";
    ModalState[ModalState["EditingGroupDescription"] = 1] = "EditingGroupDescription";
    ModalState[ModalState["EditingGroupTitle"] = 2] = "EditingGroupTitle";
    ModalState[ModalState["AddingGroupMembers"] = 3] = "AddingGroupMembers";
    ModalState[ModalState["CustomDisappearingTimeout"] = 4] = "CustomDisappearingTimeout";
})(ModalState || (ModalState = {}));
const ConversationDetails = ({ addMembers, canEditGroupInfo, candidateContactsToAdd, conversation, hasGroupLink, i18n, isAdmin, loadRecentMediaItems, memberships, pendingApprovalMemberships, pendingMemberships, setDisappearingMessages, showAllMedia, showContactModal, showGroupChatColorEditor, showGroupLinkManagement, showGroupV2Permissions, showPendingInvites, showLightboxForMedia, updateGroupAttributes, onBlock, onLeave, }) => {
    const [modalState, setModalState] = react_1.useState(ModalState.NothingOpen);
    const [editGroupAttributesRequestState, setEditGroupAttributesRequestState,] = react_1.useState(util_1.RequestState.Inactive);
    const [addGroupMembersRequestState, setAddGroupMembersRequestState,] = react_1.useState(util_1.RequestState.Inactive);
    const updateExpireTimer = (value) => {
        const intValue = parseInt(value, 10);
        if (intValue === -1) {
            setModalState(ModalState.CustomDisappearingTimeout);
        }
        else {
            setDisappearingMessages(intValue);
        }
    };
    if (conversation === undefined) {
        throw new Error('ConversationDetails rendered without a conversation');
    }
    const invitesCount = pendingMemberships.length + pendingApprovalMemberships.length;
    const otherMemberships = memberships.filter(({ member }) => !member.isMe);
    const isJustMe = otherMemberships.length === 0;
    const isAnyoneElseAnAdmin = otherMemberships.some(membership => membership.isAdmin);
    const cannotLeaveBecauseYouAreLastAdmin = isAdmin && !isJustMe && !isAnyoneElseAnAdmin;
    let modalNode;
    switch (modalState) {
        case ModalState.NothingOpen:
            modalNode = undefined;
            break;
        case ModalState.EditingGroupDescription:
        case ModalState.EditingGroupTitle:
            modalNode = (react_1.default.createElement(EditConversationAttributesModal_1.EditConversationAttributesModal, { avatarPath: conversation.avatarPath, groupDescription: conversation.groupDescription, i18n: i18n, initiallyFocusDescription: modalState === ModalState.EditingGroupDescription, makeRequest: async (options) => {
                    setEditGroupAttributesRequestState(util_1.RequestState.Active);
                    try {
                        await updateGroupAttributes(options);
                        setModalState(ModalState.NothingOpen);
                        setEditGroupAttributesRequestState(util_1.RequestState.Inactive);
                    }
                    catch (err) {
                        setEditGroupAttributesRequestState(util_1.RequestState.InactiveWithError);
                    }
                }, onClose: () => {
                    setModalState(ModalState.NothingOpen);
                    setEditGroupAttributesRequestState(util_1.RequestState.Inactive);
                }, requestState: editGroupAttributesRequestState, title: conversation.title }));
            break;
        case ModalState.AddingGroupMembers:
            modalNode = (react_1.default.createElement(AddGroupMembersModal_1.AddGroupMembersModal, { candidateContacts: candidateContactsToAdd, clearRequestError: () => {
                    setAddGroupMembersRequestState(oldRequestState => {
                        assert_1.assert(oldRequestState !== util_1.RequestState.Active, 'Should not be clearing an active request state');
                        return util_1.RequestState.Inactive;
                    });
                }, conversationIdsAlreadyInGroup: new Set(memberships.map(membership => membership.member.id)), groupTitle: conversation.title, i18n: i18n, makeRequest: async (conversationIds) => {
                    setAddGroupMembersRequestState(util_1.RequestState.Active);
                    try {
                        await addMembers(conversationIds);
                        setModalState(ModalState.NothingOpen);
                        setAddGroupMembersRequestState(util_1.RequestState.Inactive);
                    }
                    catch (err) {
                        setAddGroupMembersRequestState(util_1.RequestState.InactiveWithError);
                    }
                }, onClose: () => {
                    setModalState(ModalState.NothingOpen);
                    setEditGroupAttributesRequestState(util_1.RequestState.Inactive);
                }, requestState: addGroupMembersRequestState }));
            break;
        case ModalState.CustomDisappearingTimeout:
            modalNode = (react_1.default.createElement(DisappearingTimeDialog_1.DisappearingTimeDialog, { i18n: i18n, initialValue: conversation.expireTimer, onSubmit: value => {
                    setModalState(ModalState.NothingOpen);
                    setDisappearingMessages(value);
                }, onClose: () => setModalState(ModalState.NothingOpen) }));
            break;
        default:
            throw missingCaseError_1.missingCaseError(modalState);
    }
    const expireTimer = conversation.expireTimer || 0;
    let expirationTimerOptions = expirationTimer.DEFAULT_DURATIONS_IN_SECONDS.map(seconds => {
        const text = expirationTimer.format(i18n, seconds, {
            capitalizeOff: true,
        });
        return {
            value: seconds,
            text,
        };
    });
    const isCustomTimeSelected = !expirationTimer.DEFAULT_DURATIONS_SET.has(expireTimer);
    // Custom time...
    expirationTimerOptions = [
        ...expirationTimerOptions,
        {
            value: -1,
            text: i18n(isCustomTimeSelected
                ? 'selectedCustomDisappearingTimeOption'
                : 'customDisappearingTimeOption'),
        },
    ];
    return (react_1.default.createElement("div", { className: "conversation-details-panel" },
        react_1.default.createElement(ConversationDetailsHeader_1.ConversationDetailsHeader, { canEdit: canEditGroupInfo, conversation: conversation, i18n: i18n, memberships: memberships, startEditing: (isGroupTitle) => {
                setModalState(isGroupTitle
                    ? ModalState.EditingGroupTitle
                    : ModalState.EditingGroupDescription);
            } }),
        react_1.default.createElement(PanelSection_1.PanelSection, null,
            canEditGroupInfo ? (react_1.default.createElement(PanelRow_1.PanelRow, { icon: react_1.default.createElement(ConversationDetailsIcon_1.ConversationDetailsIcon, { ariaLabel: i18n('ConversationDetails--disappearing-messages-label'), icon: "timer" }), info: i18n('ConversationDetails--disappearing-messages-info'), label: i18n('ConversationDetails--disappearing-messages-label'), right: react_1.default.createElement(Select_1.Select, { onChange: updateExpireTimer, value: isCustomTimeSelected ? -1 : expireTimer, options: expirationTimerOptions }), rightInfo: isCustomTimeSelected
                    ? expirationTimer.format(i18n, expireTimer)
                    : undefined })) : null,
            react_1.default.createElement(PanelRow_1.PanelRow, { icon: react_1.default.createElement(ConversationDetailsIcon_1.ConversationDetailsIcon, { ariaLabel: i18n('showChatColorEditor'), icon: "color" }), label: i18n('showChatColorEditor'), onClick: showGroupChatColorEditor, right: react_1.default.createElement("div", { className: `module-conversation-details__chat-color module-conversation-details__chat-color--${conversation.conversationColor}`, style: Object.assign({}, getCustomColorStyle_1.getCustomColorStyle(conversation.customColor)) }) })),
        react_1.default.createElement(ConversationDetailsMembershipList_1.ConversationDetailsMembershipList, { canAddNewMembers: canEditGroupInfo, i18n: i18n, memberships: memberships, showContactModal: showContactModal, startAddingNewMembers: () => {
                setModalState(ModalState.AddingGroupMembers);
            } }),
        react_1.default.createElement(PanelSection_1.PanelSection, null,
            isAdmin || hasGroupLink ? (react_1.default.createElement(PanelRow_1.PanelRow, { icon: react_1.default.createElement(ConversationDetailsIcon_1.ConversationDetailsIcon, { ariaLabel: i18n('ConversationDetails--group-link'), icon: "link" }), label: i18n('ConversationDetails--group-link'), onClick: showGroupLinkManagement, right: hasGroupLink ? i18n('on') : i18n('off') })) : null,
            react_1.default.createElement(PanelRow_1.PanelRow, { icon: react_1.default.createElement(ConversationDetailsIcon_1.ConversationDetailsIcon, { ariaLabel: i18n('ConversationDetails--requests-and-invites'), icon: "invites" }), label: i18n('ConversationDetails--requests-and-invites'), onClick: showPendingInvites, right: invitesCount }),
            isAdmin ? (react_1.default.createElement(PanelRow_1.PanelRow, { icon: react_1.default.createElement(ConversationDetailsIcon_1.ConversationDetailsIcon, { ariaLabel: i18n('permissions'), icon: "lock" }), label: i18n('permissions'), onClick: showGroupV2Permissions })) : null),
        react_1.default.createElement(ConversationDetailsMediaList_1.ConversationDetailsMediaList, { conversation: conversation, i18n: i18n, loadRecentMediaItems: loadRecentMediaItems, showAllMedia: showAllMedia, showLightboxForMedia: showLightboxForMedia }),
        react_1.default.createElement(ConversationDetailsActions_1.ConversationDetailsActions, { i18n: i18n, cannotLeaveBecauseYouAreLastAdmin: cannotLeaveBecauseYouAreLastAdmin, conversationTitle: conversation.title, onLeave: onLeave, onBlock: onBlock }),
        modalNode));
};
exports.ConversationDetails = ConversationDetails;
