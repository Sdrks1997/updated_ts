"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationDetailsActions = void 0;
const react_1 = __importDefault(require("react"));
const classnames_1 = __importDefault(require("classnames"));
const ConfirmationDialog_1 = require("../../ConfirmationDialog");
const Tooltip_1 = require("../../Tooltip");
const PanelRow_1 = require("./PanelRow");
const PanelSection_1 = require("./PanelSection");
const ConversationDetailsIcon_1 = require("./ConversationDetailsIcon");
const ConversationDetailsActions = ({ cannotLeaveBecauseYouAreLastAdmin, conversationTitle, onBlock, onLeave, i18n, }) => {
    const [confirmingLeave, setConfirmingLeave] = react_1.default.useState(false);
    const [confirmingBlock, setConfirmingBlock] = react_1.default.useState(false);
    let leaveGroupNode = (react_1.default.createElement(PanelRow_1.PanelRow, { disabled: cannotLeaveBecauseYouAreLastAdmin, onClick: () => setConfirmingLeave(true), icon: react_1.default.createElement(ConversationDetailsIcon_1.ConversationDetailsIcon, { ariaLabel: i18n('ConversationDetailsActions--leave-group'), disabled: cannotLeaveBecauseYouAreLastAdmin, icon: "leave" }), label: react_1.default.createElement("div", { className: classnames_1.default('module-conversation-details__leave-group', cannotLeaveBecauseYouAreLastAdmin &&
                'module-conversation-details__leave-group--disabled') }, i18n('ConversationDetailsActions--leave-group')) }));
    if (cannotLeaveBecauseYouAreLastAdmin) {
        leaveGroupNode = (react_1.default.createElement(Tooltip_1.Tooltip, { content: i18n('ConversationDetailsActions--leave-group-must-choose-new-admin'), direction: Tooltip_1.TooltipPlacement.Top }, leaveGroupNode));
    }
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(PanelSection_1.PanelSection, null,
            leaveGroupNode,
            react_1.default.createElement(PanelRow_1.PanelRow, { onClick: () => setConfirmingBlock(true), icon: react_1.default.createElement(ConversationDetailsIcon_1.ConversationDetailsIcon, { ariaLabel: i18n('ConversationDetailsActions--block-group'), icon: "block" }), label: react_1.default.createElement("div", { className: "module-conversation-details__block-group" }, i18n('ConversationDetailsActions--block-group')) })),
        confirmingLeave && (react_1.default.createElement(ConfirmationDialog_1.ConfirmationDialog, { actions: [
                {
                    text: i18n('ConversationDetailsActions--leave-group-modal-confirm'),
                    action: onLeave,
                    style: 'affirmative',
                },
            ], i18n: i18n, onClose: () => setConfirmingLeave(false), title: i18n('ConversationDetailsActions--leave-group-modal-title') }, i18n('ConversationDetailsActions--leave-group-modal-content'))),
        confirmingBlock && (react_1.default.createElement(ConfirmationDialog_1.ConfirmationDialog, { actions: [
                {
                    text: i18n('ConversationDetailsActions--block-group-modal-confirm'),
                    action: onBlock,
                    style: 'affirmative',
                },
            ], i18n: i18n, onClose: () => setConfirmingBlock(false), title: i18n('ConversationDetailsActions--block-group-modal-title', [
                conversationTitle,
            ]) }, i18n('ConversationDetailsActions--block-group-modal-content')))));
};
exports.ConversationDetailsActions = ConversationDetailsActions;
