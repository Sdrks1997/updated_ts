"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationDetailsIcon = void 0;
const react_1 = __importDefault(require("react"));
const classnames_1 = __importDefault(require("classnames"));
const util_1 = require("./util");
const bem = util_1.bemGenerator('module-conversation-details-icon');
const ConversationDetailsIcon = ({ ariaLabel, disabled, icon, onClick, }) => {
    const iconClassName = bem('icon', icon);
    const content = (react_1.default.createElement("div", { className: classnames_1.default(iconClassName, disabled && `${iconClassName}--disabled`) }));
    if (onClick) {
        return (react_1.default.createElement("button", { "aria-label": ariaLabel, className: bem('button'), disabled: disabled, type: "button", onClick: onClick }, content));
    }
    return content;
};
exports.ConversationDetailsIcon = ConversationDetailsIcon;
