"use strict";
// Copyright 2020 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PanelRow = void 0;
const react_1 = __importDefault(require("react"));
const classnames_1 = __importDefault(require("classnames"));
const util_1 = require("./util");
const bem = util_1.bemGenerator('module-conversation-details-panel-row');
const PanelRow = ({ alwaysShowActions, className, disabled, icon, label, info, right, rightInfo, actions, onClick, }) => {
    const content = (react_1.default.createElement(react_1.default.Fragment, null,
        icon !== undefined ? react_1.default.createElement("div", { className: bem('icon') }, icon) : null,
        react_1.default.createElement("div", { className: bem('label') },
            react_1.default.createElement("div", null, label),
            info !== undefined ? react_1.default.createElement("div", { className: bem('info') }, info) : null),
        right !== undefined ? (react_1.default.createElement("div", { className: bem('right') },
            right,
            rightInfo !== undefined ? (react_1.default.createElement("div", { className: bem('right-info') }, rightInfo)) : null)) : null,
        actions !== undefined ? (react_1.default.createElement("div", { className: alwaysShowActions ? '' : bem('actions') }, actions)) : null));
    if (onClick) {
        return (react_1.default.createElement("button", { disabled: disabled, type: "button", className: classnames_1.default(bem('root', 'button'), className), onClick: onClick }, content));
    }
    return react_1.default.createElement("div", { className: classnames_1.default(bem('root'), className) }, content);
};
exports.PanelRow = PanelRow;
