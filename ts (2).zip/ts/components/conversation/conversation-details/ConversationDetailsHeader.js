"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationDetailsHeader = void 0;
const react_1 = __importDefault(require("react"));
const Avatar_1 = require("../../Avatar");
const Emojify_1 = require("../Emojify");
const GroupDescription_1 = require("../GroupDescription");
const util_1 = require("./util");
const bem = util_1.bemGenerator('module-conversation-details-header');
const ConversationDetailsHeader = ({ canEdit, conversation, i18n, memberships, startEditing, }) => {
    let subtitle;
    if (conversation.groupDescription) {
        subtitle = (react_1.default.createElement(GroupDescription_1.GroupDescription, { i18n: i18n, text: conversation.groupDescription, title: conversation.title }));
    }
    else if (canEdit) {
        subtitle = i18n('ConversationDetailsHeader--add-group-description');
    }
    else {
        subtitle = i18n('ConversationDetailsHeader--members', [
            memberships.length.toString(),
        ]);
    }
    const contents = (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(Avatar_1.Avatar, Object.assign({ conversationType: "group", i18n: i18n, size: 80 }, conversation, { sharedGroupNames: [] })),
        react_1.default.createElement("div", null,
            react_1.default.createElement("div", { className: bem('title') },
                react_1.default.createElement(Emojify_1.Emojify, { text: conversation.title })))));
    if (canEdit) {
        return (react_1.default.createElement("div", { className: bem('root') },
            react_1.default.createElement("button", { type: "button", onClick: ev => {
                    ev.preventDefault();
                    ev.stopPropagation();
                    startEditing(true);
                }, className: bem('root', 'editable') }, contents),
            react_1.default.createElement("button", { type: "button", onClick: ev => {
                    if (ev.target instanceof HTMLAnchorElement) {
                        return;
                    }
                    ev.preventDefault();
                    ev.stopPropagation();
                    startEditing(false);
                }, className: bem('root', 'editable') },
                react_1.default.createElement("div", { className: bem('subtitle') }, subtitle))));
    }
    return react_1.default.createElement("div", { className: bem('root') }, contents);
};
exports.ConversationDetailsHeader = ConversationDetailsHeader;
