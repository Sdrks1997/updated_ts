"use strict";
// Copyright 2018-2020 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AttachmentSection = void 0;
const react_1 = __importDefault(require("react"));
const DocumentListItem_1 = require("./DocumentListItem");
const MediaGridItem_1 = require("./MediaGridItem");
const missingCaseError_1 = require("../../../util/missingCaseError");
const getMessageTimestamp_1 = require("../../../util/getMessageTimestamp");
class AttachmentSection extends react_1.default.Component {
    constructor() {
        super(...arguments);
        this.createClickHandler = (mediaItem) => () => {
            const { onItemClick, type } = this.props;
            const { message, attachment } = mediaItem;
            if (!onItemClick) {
                return;
            }
            onItemClick({ type, message, attachment });
        };
    }
    render() {
        const { header } = this.props;
        return (react_1.default.createElement("div", { className: "module-attachment-section" },
            react_1.default.createElement("h2", { className: "module-attachment-section__header" }, header),
            react_1.default.createElement("div", { className: "module-attachment-section__items" }, this.renderItems())));
    }
    renderItems() {
        const { i18n, mediaItems, type } = this.props;
        return mediaItems.map((mediaItem, position, array) => {
            const shouldShowSeparator = position < array.length - 1;
            const { message, index, attachment } = mediaItem;
            const onClick = this.createClickHandler(mediaItem);
            switch (type) {
                case 'media':
                    return (react_1.default.createElement(MediaGridItem_1.MediaGridItem, { key: `${message.id}-${index}`, mediaItem: mediaItem, onClick: onClick, i18n: i18n }));
                case 'documents':
                    return (react_1.default.createElement(DocumentListItem_1.DocumentListItem, { key: `${message.id}-${index}`, fileName: attachment.fileName, fileSize: attachment.size, shouldShowSeparator: shouldShowSeparator, onClick: onClick, timestamp: getMessageTimestamp_1.getMessageTimestamp(message) }));
                default:
                    return missingCaseError_1.missingCaseError(type);
            }
        });
    }
}
exports.AttachmentSection = AttachmentSection;
