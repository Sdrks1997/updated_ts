"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importDefault(require("react"));
const react_2 = require("@storybook/react");
const addon_actions_1 = require("@storybook/addon-actions");
const getDefaultConversation_1 = require("../../test-both/helpers/getDefaultConversation");
const i18n_1 = require("../../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../../_locales/en/messages.json"));
const ConversationHeader_1 = require("./ConversationHeader");
const Fixtures_1 = require("../../storybook/Fixtures");
const book = react_2.storiesOf('Components/Conversation/ConversationHeader', module);
const i18n = i18n_1.setup('en', messages_json_1.default);
const commonProps = Object.assign(Object.assign({}, getDefaultConversation_1.getDefaultConversation()), { showBackButton: false, outgoingCallButtonStyle: ConversationHeader_1.OutgoingCallButtonStyle.Both, i18n, onShowConversationDetails: addon_actions_1.action('onShowConversationDetails'), onSetDisappearingMessages: addon_actions_1.action('onSetDisappearingMessages'), onDeleteMessages: addon_actions_1.action('onDeleteMessages'), onResetSession: addon_actions_1.action('onResetSession'), onSearchInConversation: addon_actions_1.action('onSearchInConversation'), onSetMuteNotifications: addon_actions_1.action('onSetMuteNotifications'), onOutgoingAudioCallInConversation: addon_actions_1.action('onOutgoingAudioCallInConversation'), onOutgoingVideoCallInConversation: addon_actions_1.action('onOutgoingVideoCallInConversation'), onShowChatColorEditor: addon_actions_1.action('onShowChatColorEditor'), onShowSafetyNumber: addon_actions_1.action('onShowSafetyNumber'), onShowAllMedia: addon_actions_1.action('onShowAllMedia'), onShowContactModal: addon_actions_1.action('onShowContactModal'), onShowGroupMembers: addon_actions_1.action('onShowGroupMembers'), onGoBack: addon_actions_1.action('onGoBack'), onArchive: addon_actions_1.action('onArchive'), onMarkUnread: addon_actions_1.action('onMarkUnread'), onMoveToInbox: addon_actions_1.action('onMoveToInbox'), onSetPin: addon_actions_1.action('onSetPin') });
const stories = [
    {
        title: '1:1 conversation',
        description: "Note the five items in menu, and the second-level menu with disappearing messages options. Disappearing message set to 'off'.",
        items: [
            {
                title: 'With name and profile, verified',
                props: Object.assign(Object.assign({}, commonProps), { color: 'crimson', isVerified: true, avatarPath: Fixtures_1.gifUrl, title: 'Someone 🔥 Somewhere', name: 'Someone 🔥 Somewhere', phoneNumber: '(202) 555-0001', type: 'direct', id: '1', profileName: '🔥Flames🔥', acceptedMessageRequest: true }),
            },
            {
                title: 'With name, not verified, no avatar',
                props: Object.assign(Object.assign({}, commonProps), { color: 'blue', isVerified: false, title: 'Someone 🔥 Somewhere', name: 'Someone 🔥 Somewhere', phoneNumber: '(202) 555-0002', type: 'direct', id: '2', acceptedMessageRequest: true }),
            },
            {
                title: 'With name, not verified, descenders',
                props: Object.assign(Object.assign({}, commonProps), { color: 'blue', isVerified: false, title: 'Joyrey 🔥 Leppey', name: 'Joyrey 🔥 Leppey', phoneNumber: '(202) 555-0002', type: 'direct', id: '3', acceptedMessageRequest: true }),
            },
            {
                title: 'Profile, no name',
                props: Object.assign(Object.assign({}, commonProps), { color: 'wintergreen', isVerified: false, phoneNumber: '(202) 555-0003', type: 'direct', id: '4', title: '🔥Flames🔥', profileName: '🔥Flames🔥', acceptedMessageRequest: true }),
            },
            {
                title: 'No name, no profile, no color',
                props: Object.assign(Object.assign({}, commonProps), { title: '(202) 555-0011', phoneNumber: '(202) 555-0011', type: 'direct', id: '5', acceptedMessageRequest: true }),
            },
            {
                title: 'With back button',
                props: Object.assign(Object.assign({}, commonProps), { showBackButton: true, color: 'vermilion', phoneNumber: '(202) 555-0004', title: '(202) 555-0004', type: 'direct', id: '6', acceptedMessageRequest: true }),
            },
            {
                title: 'Disappearing messages set',
                props: Object.assign(Object.assign({}, commonProps), { color: 'indigo', title: '(202) 555-0005', phoneNumber: '(202) 555-0005', type: 'direct', id: '7', expireTimer: 10, acceptedMessageRequest: true }),
            },
            {
                title: 'Disappearing messages + verified',
                props: Object.assign(Object.assign({}, commonProps), { color: 'indigo', title: '(202) 555-0005', phoneNumber: '(202) 555-0005', type: 'direct', id: '8', expireTimer: 300, acceptedMessageRequest: true, isVerified: true, canChangeTimer: true }),
            },
            {
                title: 'Muting Conversation',
                props: Object.assign(Object.assign({}, commonProps), { color: 'ultramarine', title: '(202) 555-0006', phoneNumber: '(202) 555-0006', type: 'direct', id: '9', acceptedMessageRequest: true, muteExpiresAt: new Date('3000-10-18T11:11:11Z').valueOf() }),
            },
            {
                title: 'SMS-only conversation',
                props: Object.assign(Object.assign({}, commonProps), { color: 'ultramarine', title: '(202) 555-0006', phoneNumber: '(202) 555-0006', type: 'direct', id: '10', acceptedMessageRequest: true, isSMSOnly: true }),
            },
        ],
    },
    {
        title: 'In a group',
        description: "Note that the menu should includes 'Show Members' instead of 'Show Safety Number'",
        items: [
            {
                title: 'Basic',
                props: Object.assign(Object.assign({}, commonProps), { color: 'ultramarine', title: 'Typescript support group', name: 'Typescript support group', phoneNumber: '', id: '11', type: 'group', expireTimer: 10, acceptedMessageRequest: true, outgoingCallButtonStyle: ConversationHeader_1.OutgoingCallButtonStyle.JustVideo }),
            },
            {
                title: 'In a group you left - no disappearing messages',
                props: Object.assign(Object.assign({}, commonProps), { color: 'ultramarine', title: 'Typescript support group', name: 'Typescript support group', phoneNumber: '', id: '12', type: 'group', left: true, expireTimer: 10, acceptedMessageRequest: true, outgoingCallButtonStyle: ConversationHeader_1.OutgoingCallButtonStyle.JustVideo }),
            },
            {
                title: 'In a group with an active group call',
                props: Object.assign(Object.assign({}, commonProps), { color: 'ultramarine', title: 'Typescript support group', name: 'Typescript support group', phoneNumber: '', id: '13', type: 'group', expireTimer: 10, acceptedMessageRequest: true, outgoingCallButtonStyle: ConversationHeader_1.OutgoingCallButtonStyle.Join }),
            },
            {
                title: 'In a forever muted group',
                props: Object.assign(Object.assign({}, commonProps), { color: 'ultramarine', title: 'Way too many messages', name: 'Way too many messages', phoneNumber: '', id: '14', type: 'group', expireTimer: 10, acceptedMessageRequest: true, outgoingCallButtonStyle: ConversationHeader_1.OutgoingCallButtonStyle.JustVideo, muteExpiresAt: Infinity }),
            },
        ],
    },
    {
        title: 'Note to Self',
        description: 'No safety number entry.',
        items: [
            {
                title: 'In chat with yourself',
                props: Object.assign(Object.assign({}, commonProps), { color: 'blue', title: '(202) 555-0007', phoneNumber: '(202) 555-0007', id: '15', type: 'direct', isMe: true, acceptedMessageRequest: true, outgoingCallButtonStyle: ConversationHeader_1.OutgoingCallButtonStyle.None }),
            },
        ],
    },
    {
        title: 'Unaccepted',
        description: 'No safety number entry.',
        items: [
            {
                title: '1:1 conversation',
                props: Object.assign(Object.assign({}, commonProps), { color: 'blue', title: '(202) 555-0007', phoneNumber: '(202) 555-0007', id: '16', type: 'direct', isMe: false, acceptedMessageRequest: false, outgoingCallButtonStyle: ConversationHeader_1.OutgoingCallButtonStyle.None }),
            },
        ],
    },
];
stories.forEach(({ title, description, items }) => book.add(title, () => items.map(({ title: subtitle, props }, i) => {
    return (react_1.default.createElement("div", { key: i },
        subtitle ? react_1.default.createElement("h3", null, subtitle) : null,
        react_1.default.createElement(ConversationHeader_1.ConversationHeader, Object.assign({}, props))));
}), {
    docs: description,
}));
