"use strict";
// Copyright 2019-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StagedPlaceholderAttachment = void 0;
const react_1 = __importDefault(require("react"));
const StagedPlaceholderAttachment = ({ i18n, onClick, }) => (react_1.default.createElement("button", { type: "button", className: "module-staged-placeholder-attachment", onClick: onClick, title: i18n('add-image-attachment') },
    react_1.default.createElement("div", { className: "module-staged-placeholder-attachment__plus-icon" })));
exports.StagedPlaceholderAttachment = StagedPlaceholderAttachment;
