"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationHero = void 0;
const react_1 = __importStar(require("react"));
const react_measure_1 = __importDefault(require("react-measure"));
const Avatar_1 = require("../Avatar");
const ContactName_1 = require("./ContactName");
const About_1 = require("./About");
const GroupDescription_1 = require("./GroupDescription");
const SharedGroupNames_1 = require("../SharedGroupNames");
const ConfirmationDialog_1 = require("../ConfirmationDialog");
const Button_1 = require("../Button");
const assert_1 = require("../../util/assert");
const shouldBlurAvatar_1 = require("../../util/shouldBlurAvatar");
const renderMembershipRow = ({ acceptedMessageRequest, conversationType, i18n, isMe, onClickMessageRequestWarning, phoneNumber, sharedGroupNames, }) => {
    const className = 'module-conversation-hero__membership';
    if (conversationType !== 'direct') {
        return null;
    }
    if (isMe) {
        return react_1.default.createElement("div", { className: className }, i18n('noteToSelfHero'));
    }
    if (sharedGroupNames.length > 0) {
        return (react_1.default.createElement("div", { className: className },
            react_1.default.createElement(SharedGroupNames_1.SharedGroupNames, { i18n: i18n, nameClassName: `${className}__name`, sharedGroupNames: sharedGroupNames })));
    }
    if (acceptedMessageRequest) {
        if (phoneNumber) {
            return null;
        }
        return react_1.default.createElement("div", { className: className }, i18n('no-groups-in-common'));
    }
    return (react_1.default.createElement("div", { className: "module-conversation-hero__message-request-warning" },
        react_1.default.createElement("div", { className: "module-conversation-hero__message-request-warning__message" }, i18n('no-groups-in-common-warning')),
        react_1.default.createElement(Button_1.Button, { onClick: onClickMessageRequestWarning, size: Button_1.ButtonSize.Small, variant: Button_1.ButtonVariant.SecondaryAffirmative }, i18n('MessageRequestWarning__learn-more'))));
};
const ConversationHero = ({ i18n, about, acceptedMessageRequest, avatarPath, color, conversationType, groupDescription, isMe, membersCount, sharedGroupNames = [], name, phoneNumber, profileName, title, onHeightChange, unblurAvatar, unblurredAvatarPath, updateSharedGroups, }) => {
    const firstRenderRef = react_1.useRef(true);
    const previousHeightRef = react_1.useRef();
    const [height, setHeight] = react_1.useState();
    const [isShowingMessageRequestWarning, setIsShowingMessageRequestWarning,] = react_1.useState(false);
    const closeMessageRequestWarning = () => {
        setIsShowingMessageRequestWarning(false);
    };
    react_1.useEffect(() => {
        // Kick off the expensive hydration of the current sharedGroupNames
        updateSharedGroups();
    }, [updateSharedGroups]);
    react_1.useEffect(() => {
        firstRenderRef.current = false;
    }, []);
    react_1.useEffect(() => {
        // We only want to kick off a "height change" when the height goes from number to
        //   number. We DON'T want to do it when we measure the height for the first time, as
        //   this will cause a re-render loop.
        const previousHeight = previousHeightRef.current;
        if (previousHeight && height && previousHeight !== height) {
            onHeightChange === null || onHeightChange === void 0 ? void 0 : onHeightChange();
        }
    }, [height, onHeightChange]);
    react_1.useEffect(() => {
        previousHeightRef.current = height;
    }, [height]);
    let avatarBlur;
    let avatarOnClick;
    if (shouldBlurAvatar_1.shouldBlurAvatar({
        acceptedMessageRequest,
        avatarPath,
        isMe,
        sharedGroupNames,
        unblurredAvatarPath,
    })) {
        avatarBlur = Avatar_1.AvatarBlur.BlurPictureWithClickToView;
        avatarOnClick = unblurAvatar;
    }
    else {
        avatarBlur = Avatar_1.AvatarBlur.NoBlur;
    }
    const phoneNumberOnly = Boolean(!name && !profileName && conversationType === 'direct');
    /* eslint-disable no-nested-ternary */
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(react_measure_1.default, { bounds: true, onResize: ({ bounds }) => {
                assert_1.assert(bounds, 'We should be measuring the bounds');
                setHeight(bounds.height);
            } }, ({ measureRef }) => (react_1.default.createElement("div", { className: "module-conversation-hero", ref: measureRef },
            react_1.default.createElement(Avatar_1.Avatar, { acceptedMessageRequest: acceptedMessageRequest, avatarPath: avatarPath, blur: avatarBlur, className: "module-conversation-hero__avatar", color: color, conversationType: conversationType, i18n: i18n, isMe: isMe, name: name, noteToSelf: isMe, onClick: avatarOnClick, profileName: profileName, sharedGroupNames: sharedGroupNames, size: 112, title: title }),
            react_1.default.createElement("h1", { className: "module-conversation-hero__profile-name" }, isMe ? (i18n('noteToSelf')) : (react_1.default.createElement(ContactName_1.ContactName, { title: title, name: name, profileName: profileName, phoneNumber: phoneNumber, i18n: i18n }))),
            about && !isMe && (react_1.default.createElement("div", { className: "module-about__container" },
                react_1.default.createElement(About_1.About, { text: about }))),
            !isMe ? (react_1.default.createElement("div", { className: "module-conversation-hero__with" }, groupDescription ? (react_1.default.createElement(GroupDescription_1.GroupDescription, { i18n: i18n, title: title, text: groupDescription })) : membersCount === 1 ? (i18n('ConversationHero--members-1')) : membersCount !== undefined ? (i18n('ConversationHero--members', [`${membersCount}`])) : phoneNumberOnly ? null : (phoneNumber))) : null,
            renderMembershipRow({
                acceptedMessageRequest,
                conversationType,
                i18n,
                isMe,
                onClickMessageRequestWarning() {
                    setIsShowingMessageRequestWarning(true);
                },
                phoneNumber,
                sharedGroupNames,
            })))),
        isShowingMessageRequestWarning && (react_1.default.createElement(ConfirmationDialog_1.ConfirmationDialog, { i18n: i18n, onClose: closeMessageRequestWarning, actions: [
                {
                    text: i18n('MessageRequestWarning__dialog__learn-even-more'),
                    action: () => {
                        window.location.href =
                            'https://support.signal.org/hc/articles/360007459591';
                        closeMessageRequestWarning();
                    },
                },
            ] }, i18n('MessageRequestWarning__dialog__details')))));
    /* eslint-enable no-nested-ternary */
};
exports.ConversationHero = ConversationHero;
