"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const addon_actions_1 = require("@storybook/addon-actions");
const addon_knobs_1 = require("@storybook/addon-knobs");
const react_1 = require("@storybook/react");
const MessageDetail_1 = require("./MessageDetail");
const getDefaultConversation_1 = require("../../test-both/helpers/getDefaultConversation");
const i18n_1 = require("../../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../../_locales/en/messages.json"));
const i18n = i18n_1.setup('en', messages_json_1.default);
const story = react_1.storiesOf('Components/Conversation/MessageDetail', module);
const defaultMessage = {
    author: getDefaultConversation_1.getDefaultConversation({
        id: 'some-id',
        title: 'Max',
    }),
    canReply: true,
    canDeleteForEveryone: true,
    canDownload: true,
    conversationColor: 'crimson',
    conversationId: 'my-convo',
    conversationType: 'direct',
    direction: 'incoming',
    id: 'my-message',
    isBlocked: false,
    isMessageRequestAccepted: true,
    previews: [],
    status: 'sent',
    text: 'A message from Max',
    timestamp: Date.now(),
};
const createProps = (overrideProps = {}) => ({
    contacts: overrideProps.contacts || [
        Object.assign(Object.assign({}, getDefaultConversation_1.getDefaultConversation({
            color: 'indigo',
            title: 'Just Max',
        })), { isOutgoingKeyError: false, isUnidentifiedDelivery: false, status: 'delivered' }),
    ],
    errors: overrideProps.errors || [],
    message: overrideProps.message || defaultMessage,
    receivedAt: addon_knobs_1.number('receivedAt', overrideProps.receivedAt || Date.now()),
    sentAt: addon_knobs_1.number('sentAt', overrideProps.sentAt || Date.now()),
    i18n,
    interactionMode: 'keyboard',
    sendAnyway: addon_actions_1.action('onSendAnyway'),
    showSafetyNumber: addon_actions_1.action('onShowSafetyNumber'),
    checkForAccount: addon_actions_1.action('checkForAccount'),
    clearSelectedMessage: addon_actions_1.action('clearSelectedMessage'),
    deleteMessage: addon_actions_1.action('deleteMessage'),
    deleteMessageForEveryone: addon_actions_1.action('deleteMessageForEveryone'),
    displayTapToViewMessage: addon_actions_1.action('displayTapToViewMessage'),
    downloadAttachment: addon_actions_1.action('downloadAttachment'),
    doubleCheckMissingQuoteReference: addon_actions_1.action('doubleCheckMissingQuoteReference'),
    kickOffAttachmentDownload: addon_actions_1.action('kickOffAttachmentDownload'),
    markAttachmentAsCorrupted: addon_actions_1.action('markAttachmentAsCorrupted'),
    openConversation: addon_actions_1.action('openConversation'),
    openLink: addon_actions_1.action('openLink'),
    reactToMessage: addon_actions_1.action('reactToMessage'),
    renderAudioAttachment: () => React.createElement("div", null, "*AudioAttachment*"),
    renderEmojiPicker: () => React.createElement("div", null),
    replyToMessage: addon_actions_1.action('replyToMessage'),
    retrySend: addon_actions_1.action('retrySend'),
    showContactDetail: addon_actions_1.action('showContactDetail'),
    showContactModal: addon_actions_1.action('showContactModal'),
    showExpiredIncomingTapToViewToast: addon_actions_1.action('showExpiredIncomingTapToViewToast'),
    showExpiredOutgoingTapToViewToast: addon_actions_1.action('showExpiredOutgoingTapToViewToast'),
    showForwardMessageModal: addon_actions_1.action('showForwardMessageModal'),
    showVisualAttachment: addon_actions_1.action('showVisualAttachment'),
});
story.add('Delivered Incoming', () => {
    const props = createProps({});
    return React.createElement(MessageDetail_1.MessageDetail, Object.assign({}, props));
});
story.add('Delivered Outgoing', () => {
    const props = createProps({
        message: Object.assign(Object.assign({}, defaultMessage), { direction: 'outgoing', text: 'A message to Max' }),
    });
    return React.createElement(MessageDetail_1.MessageDetail, Object.assign({}, props));
});
story.add('Message Statuses', () => {
    const props = createProps({
        contacts: [
            Object.assign(Object.assign({}, getDefaultConversation_1.getDefaultConversation({
                color: 'forest',
                title: 'Max',
            })), { isOutgoingKeyError: false, isUnidentifiedDelivery: false, status: 'sent' }),
            Object.assign(Object.assign({}, getDefaultConversation_1.getDefaultConversation({
                color: 'blue',
                title: 'Sally',
            })), { isOutgoingKeyError: false, isUnidentifiedDelivery: false, status: 'sending' }),
            Object.assign(Object.assign({}, getDefaultConversation_1.getDefaultConversation({
                color: 'burlap',
                title: 'Terry',
            })), { isOutgoingKeyError: false, isUnidentifiedDelivery: false, status: 'partial-sent' }),
            Object.assign(Object.assign({}, getDefaultConversation_1.getDefaultConversation({
                color: 'wintergreen',
                title: 'Theo',
            })), { isOutgoingKeyError: false, isUnidentifiedDelivery: false, status: 'delivered' }),
            Object.assign(Object.assign({}, getDefaultConversation_1.getDefaultConversation({
                color: 'steel',
                title: 'Nikki',
            })), { isOutgoingKeyError: false, isUnidentifiedDelivery: false, status: 'read' }),
        ],
        message: Object.assign(Object.assign({}, defaultMessage), { conversationType: 'group', text: 'A message to you all!' }),
    });
    return React.createElement(MessageDetail_1.MessageDetail, Object.assign({}, props));
});
story.add('Not Delivered', () => {
    const props = createProps({
        message: Object.assign(Object.assign({}, defaultMessage), { direction: 'outgoing', text: 'A message to Max' }),
    });
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    props.receivedAt = undefined;
    return React.createElement(MessageDetail_1.MessageDetail, Object.assign({}, props));
});
story.add('No Contacts', () => {
    const props = createProps({
        contacts: [],
        message: Object.assign(Object.assign({}, defaultMessage), { direction: 'outgoing', text: 'Is anybody there?' }),
    });
    return React.createElement(MessageDetail_1.MessageDetail, Object.assign({}, props));
});
story.add('All Errors', () => {
    const props = createProps({
        errors: [
            {
                name: 'Another Error',
                message: 'Wow, that went bad.',
            },
        ],
        message: Object.assign({}, defaultMessage),
        contacts: [
            Object.assign(Object.assign({}, getDefaultConversation_1.getDefaultConversation({
                color: 'forest',
                title: 'Max',
            })), { isOutgoingKeyError: true, isUnidentifiedDelivery: false, status: 'error' }),
            Object.assign(Object.assign({}, getDefaultConversation_1.getDefaultConversation({
                color: 'blue',
                title: 'Sally',
            })), { errors: [
                    {
                        name: 'Big Error',
                        message: 'Stuff happened, in a bad way.',
                    },
                ], isOutgoingKeyError: false, isUnidentifiedDelivery: true, status: 'error' }),
            Object.assign(Object.assign({}, getDefaultConversation_1.getDefaultConversation({
                color: 'taupe',
                title: 'Terry',
            })), { isOutgoingKeyError: true, isUnidentifiedDelivery: true, status: 'error' }),
        ],
    });
    return React.createElement(MessageDetail_1.MessageDetail, Object.assign({}, props));
});
