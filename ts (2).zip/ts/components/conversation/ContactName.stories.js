"use strict";
// Copyright 2020 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const react_1 = require("@storybook/react");
const i18n_1 = require("../../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../../_locales/en/messages.json"));
const ContactName_1 = require("./ContactName");
const Colors_1 = require("../../types/Colors");
const i18n = i18n_1.setup('en', messages_json_1.default);
react_1.storiesOf('Components/Conversation/ContactName', module)
    .add('Number, name and profile', () => {
    return (React.createElement(ContactName_1.ContactName, { title: "Someone \uD83D\uDD25 Somewhere", name: "Someone \uD83D\uDD25 Somewhere", phoneNumber: "(202) 555-0011", profileName: "\uD83D\uDD25Flames\uD83D\uDD25", i18n: i18n }));
})
    .add('Number and profile, no name', () => {
    return (React.createElement(ContactName_1.ContactName, { title: "\uD83D\uDD25Flames\uD83D\uDD25", phoneNumber: "(202) 555-0011", profileName: "\uD83D\uDD25Flames\uD83D\uDD25", i18n: i18n }));
})
    .add('No name, no profile', () => {
    return (React.createElement(ContactName_1.ContactName, { title: "(202) 555-0011", phoneNumber: "(202) 555-0011", i18n: i18n }));
})
    .add('Colors', () => {
    return Colors_1.ContactNameColors.map(color => (React.createElement("div", { key: color },
        React.createElement(ContactName_1.ContactName, { title: `Hello ${color}`, contactNameColor: color, i18n: i18n, phoneNumber: "(202) 555-0011" }))));
})
    .add('No data provided', () => {
    return React.createElement(ContactName_1.ContactName, { title: "unknownContact", i18n: i18n });
});
