"use strict";
// Copyright 2018-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageDetail = void 0;
const react_1 = __importDefault(require("react"));
const classnames_1 = __importDefault(require("classnames"));
const moment_1 = __importDefault(require("moment"));
const lodash_1 = require("lodash");
const GlobalAudioContext_1 = require("../GlobalAudioContext");
const Avatar_1 = require("../Avatar");
const ContactName_1 = require("./ContactName");
const Message_1 = require("./Message");
const assert_1 = require("../../util/assert");
const _keyForError = (error) => {
    return `${error.name}-${error.message}`;
};
class MessageDetail extends react_1.default.Component {
    constructor() {
        super(...arguments);
        this.focusRef = react_1.default.createRef();
    }
    componentDidMount() {
        // When this component is created, it's initially not part of the DOM, and then it's
        //   added off-screen and animated in. This ensures that the focus takes.
        setTimeout(() => {
            if (this.focusRef.current) {
                this.focusRef.current.focus();
            }
        });
    }
    renderAvatar(contact) {
        const { i18n } = this.props;
        const { acceptedMessageRequest, avatarPath, color, isMe, name, phoneNumber, profileName, sharedGroupNames, title, unblurredAvatarPath, } = contact;
        return (react_1.default.createElement(Avatar_1.Avatar, { acceptedMessageRequest: acceptedMessageRequest, avatarPath: avatarPath, color: color, conversationType: "direct", i18n: i18n, isMe: isMe, name: name, phoneNumber: phoneNumber, profileName: profileName, title: title, sharedGroupNames: sharedGroupNames, size: 52, unblurredAvatarPath: unblurredAvatarPath }));
    }
    renderDeleteButton() {
        const { deleteMessage, i18n, message } = this.props;
        return (react_1.default.createElement("div", { className: "module-message-detail__delete-button-container" },
            react_1.default.createElement("button", { type: "button", onClick: () => {
                    deleteMessage(message.id);
                }, className: "module-message-detail__delete-button" }, i18n('deleteThisMessage'))));
    }
    renderContact(contact) {
        const { i18n, message, showSafetyNumber, sendAnyway } = this.props;
        const errors = contact.errors || [];
        const errorComponent = contact.isOutgoingKeyError ? (react_1.default.createElement("div", { className: "module-message-detail__contact__error-buttons" },
            react_1.default.createElement("button", { type: "button", className: "module-message-detail__contact__show-safety-number", onClick: () => showSafetyNumber(contact.id) }, i18n('showSafetyNumber')),
            react_1.default.createElement("button", { type: "button", className: "module-message-detail__contact__send-anyway", onClick: () => sendAnyway(contact.id, message.id) }, i18n('sendAnyway')))) : null;
        const statusComponent = !contact.isOutgoingKeyError ? (react_1.default.createElement("div", { className: classnames_1.default('module-message-detail__contact__status-icon', contact.status
                ? `module-message-detail__contact__status-icon--${contact.status}`
                : undefined) })) : null;
        const unidentifiedDeliveryComponent = contact.isUnidentifiedDelivery ? (react_1.default.createElement("div", { className: "module-message-detail__contact__unidentified-delivery-icon" })) : null;
        return (react_1.default.createElement("div", { key: contact.phoneNumber, className: "module-message-detail__contact" },
            this.renderAvatar(contact),
            react_1.default.createElement("div", { className: "module-message-detail__contact__text" },
                react_1.default.createElement("div", { className: "module-message-detail__contact__name" },
                    react_1.default.createElement(ContactName_1.ContactName, { phoneNumber: contact.phoneNumber, name: contact.name, profileName: contact.profileName, title: contact.title, i18n: i18n })),
                errors.map(error => (react_1.default.createElement("div", { key: _keyForError(error), className: "module-message-detail__contact__error" }, error.message)))),
            errorComponent,
            unidentifiedDeliveryComponent,
            statusComponent));
    }
    renderContacts() {
        const { contacts } = this.props;
        if (!contacts || !contacts.length) {
            return null;
        }
        return (react_1.default.createElement("div", { className: "module-message-detail__contact-container" }, contacts.map(contact => this.renderContact(contact))));
    }
    render() {
        const { errors, message, receivedAt, sentAt, checkForAccount, clearSelectedMessage, contactNameColor, deleteMessage, deleteMessageForEveryone, displayTapToViewMessage, downloadAttachment, doubleCheckMissingQuoteReference, i18n, interactionMode, kickOffAttachmentDownload, markAttachmentAsCorrupted, openConversation, openLink, reactToMessage, renderAudioAttachment, renderEmojiPicker, replyToMessage, retrySend, showContactDetail, showContactModal, showExpiredIncomingTapToViewToast, showExpiredOutgoingTapToViewToast, showForwardMessageModal, showVisualAttachment, } = this.props;
        return (
        // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
        react_1.default.createElement("div", { className: "module-message-detail", tabIndex: 0, ref: this.focusRef },
            react_1.default.createElement("div", { className: "module-message-detail__message-container" },
                react_1.default.createElement(GlobalAudioContext_1.GlobalAudioProvider, { conversationId: message.conversationId },
                    react_1.default.createElement(Message_1.Message, Object.assign({}, message, { checkForAccount: checkForAccount, clearSelectedMessage: clearSelectedMessage, contactNameColor: contactNameColor, deleteMessage: deleteMessage, deleteMessageForEveryone: deleteMessageForEveryone, disableMenu: true, disableScroll: true, displayTapToViewMessage: displayTapToViewMessage, downloadAttachment: downloadAttachment, doubleCheckMissingQuoteReference: doubleCheckMissingQuoteReference, i18n: i18n, interactionMode: interactionMode, kickOffAttachmentDownload: kickOffAttachmentDownload, markAttachmentAsCorrupted: markAttachmentAsCorrupted, onHeightChange: lodash_1.noop, openConversation: openConversation, openLink: openLink, reactToMessage: reactToMessage, renderAudioAttachment: renderAudioAttachment, renderEmojiPicker: renderEmojiPicker, replyToMessage: replyToMessage, retrySend: retrySend, showForwardMessageModal: showForwardMessageModal, scrollToQuotedMessage: () => {
                            assert_1.assert(false, 'scrollToQuotedMessage should never be called because scrolling is disabled');
                        }, showContactDetail: showContactDetail, showContactModal: showContactModal, showExpiredIncomingTapToViewToast: showExpiredIncomingTapToViewToast, showExpiredOutgoingTapToViewToast: showExpiredOutgoingTapToViewToast, showMessageDetail: () => {
                            assert_1.assert(false, "showMessageDetail should never be called because the menu is disabled (and we're already in the message detail!)");
                        }, showVisualAttachment: showVisualAttachment })))),
            react_1.default.createElement("table", { className: "module-message-detail__info" },
                react_1.default.createElement("tbody", null,
                    (errors || []).map(error => (react_1.default.createElement("tr", { key: _keyForError(error) },
                        react_1.default.createElement("td", { className: "module-message-detail__label" }, i18n('error')),
                        react_1.default.createElement("td", null,
                            ' ',
                            react_1.default.createElement("span", { className: "error-message" }, error.message),
                            ' ')))),
                    react_1.default.createElement("tr", null,
                        react_1.default.createElement("td", { className: "module-message-detail__label" }, i18n('sent')),
                        react_1.default.createElement("td", null,
                            moment_1.default(sentAt).format('LLLL'),
                            ' ',
                            react_1.default.createElement("span", { className: "module-message-detail__unix-timestamp" },
                                "(",
                                sentAt,
                                ")"))),
                    receivedAt ? (react_1.default.createElement("tr", null,
                        react_1.default.createElement("td", { className: "module-message-detail__label" }, i18n('received')),
                        react_1.default.createElement("td", null,
                            moment_1.default(receivedAt).format('LLLL'),
                            ' ',
                            react_1.default.createElement("span", { className: "module-message-detail__unix-timestamp" },
                                "(",
                                receivedAt,
                                ")")))) : null,
                    react_1.default.createElement("tr", null,
                        react_1.default.createElement("td", { className: "module-message-detail__label" }, message.direction === 'incoming' ? i18n('from') : i18n('to'))))),
            this.renderContacts(),
            this.renderDeleteButton()));
    }
}
exports.MessageDetail = MessageDetail;
