"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GroupV2Change = void 0;
const react_1 = __importStar(require("react"));
const Intl_1 = require("../Intl");
const GroupDescriptionText_1 = require("../GroupDescriptionText");
const Button_1 = require("../Button");
const groupChange_1 = require("../../groupChange");
const Modal_1 = require("../Modal");
function renderStringToIntl(id, i18n, components) {
    return react_1.default.createElement(Intl_1.Intl, { id: id, i18n: i18n, components: components });
}
function GroupV2Change(props) {
    var _a;
    const { AccessControlEnum, change, groupName, i18n, ourConversationId, renderContact, RoleEnum, } = props;
    const [isGroupDescriptionDialogOpen, setIsGroupDescriptionDialogOpen,] = react_1.useState(false);
    const newGroupDescription = (_a = change.details.find((item) => Boolean(item.type === 'description' && item.description))) === null || _a === void 0 ? void 0 : _a.description;
    return (react_1.default.createElement("div", { className: "module-group-v2-change" },
        react_1.default.createElement("div", { className: "module-group-v2-change--icon" }),
        groupChange_1.renderChange(change, {
            AccessControlEnum,
            i18n,
            ourConversationId,
            renderContact,
            renderString: renderStringToIntl,
            RoleEnum,
        }).map((item, index) => (
        // Difficult to find a unique key for this type
        // eslint-disable-next-line react/no-array-index-key
        react_1.default.createElement("div", { key: index }, item))),
        newGroupDescription ? (react_1.default.createElement("div", { className: "module-group-v2-change--button-container" },
            react_1.default.createElement(Button_1.Button, { size: Button_1.ButtonSize.Small, variant: Button_1.ButtonVariant.SecondaryAffirmative, onClick: () => setIsGroupDescriptionDialogOpen(true) }, i18n('view')))) : null,
        newGroupDescription && isGroupDescriptionDialogOpen ? (react_1.default.createElement(Modal_1.Modal, { hasXButton: true, i18n: i18n, title: groupName, onClose: () => setIsGroupDescriptionDialogOpen(false) },
            react_1.default.createElement(GroupDescriptionText_1.GroupDescriptionText, { text: newGroupDescription }))) : null));
}
exports.GroupV2Change = GroupV2Change;
