"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContactModal = void 0;
const react_1 = __importDefault(require("react"));
const react_dom_1 = require("react-dom");
const About_1 = require("./About");
const Avatar_1 = require("../Avatar");
const SharedGroupNames_1 = require("../SharedGroupNames");
const ContactModal = ({ areWeAdmin, contact, i18n, isAdmin, isMember, onClose, openConversation, removeMember, showSafetyNumber, toggleAdmin, updateSharedGroups, }) => {
    if (!contact) {
        throw new Error('Contact modal opened without a matching contact');
    }
    const [root, setRoot] = react_1.default.useState(null);
    const overlayRef = react_1.default.useRef(null);
    const closeButtonRef = react_1.default.useRef(null);
    react_1.default.useEffect(() => {
        const div = document.createElement('div');
        document.body.appendChild(div);
        setRoot(div);
        return () => {
            document.body.removeChild(div);
            setRoot(null);
        };
    }, []);
    react_1.default.useEffect(() => {
        // Kick off the expensive hydration of the current sharedGroupNames
        updateSharedGroups();
    }, [updateSharedGroups]);
    react_1.default.useEffect(() => {
        if (root !== null && closeButtonRef.current) {
            closeButtonRef.current.focus();
        }
    }, [root]);
    react_1.default.useEffect(() => {
        const handler = (event) => {
            if (event.key === 'Escape') {
                event.preventDefault();
                event.stopPropagation();
                onClose();
            }
        };
        document.addEventListener('keyup', handler);
        return () => {
            document.removeEventListener('keyup', handler);
        };
    }, [onClose]);
    const onClickOverlay = (e) => {
        if (e.target === overlayRef.current) {
            e.preventDefault();
            e.stopPropagation();
            onClose();
        }
    };
    return root
        ? react_dom_1.createPortal(react_1.default.createElement("div", { ref: ref => {
                overlayRef.current = ref;
            }, role: "presentation", className: "module-contact-modal__overlay", onClick: onClickOverlay },
            react_1.default.createElement("div", { className: "module-contact-modal" },
                react_1.default.createElement("button", { ref: r => {
                        closeButtonRef.current = r;
                    }, type: "button", className: "module-contact-modal__close-button", onClick: onClose, "aria-label": i18n('close') }),
                react_1.default.createElement(Avatar_1.Avatar, { acceptedMessageRequest: contact.acceptedMessageRequest, avatarPath: contact.avatarPath, color: contact.color, conversationType: "direct", i18n: i18n, isMe: contact.isMe, name: contact.name, profileName: contact.profileName, sharedGroupNames: contact.sharedGroupNames, size: 96, title: contact.title, unblurredAvatarPath: contact.unblurredAvatarPath }),
                react_1.default.createElement("div", { className: "module-contact-modal__name" }, contact.title),
                react_1.default.createElement("div", { className: "module-about__container" },
                    react_1.default.createElement(About_1.About, { text: contact.about })),
                contact.phoneNumber && (react_1.default.createElement("div", { className: "module-contact-modal__info" }, contact.phoneNumber)),
                react_1.default.createElement("div", { className: "module-contact-modal__info" },
                    react_1.default.createElement(SharedGroupNames_1.SharedGroupNames, { i18n: i18n, sharedGroupNames: contact.sharedGroupNames || [] })),
                react_1.default.createElement("div", { className: "module-contact-modal__button-container" },
                    react_1.default.createElement("button", { type: "button", className: "module-contact-modal__button module-contact-modal__send-message", onClick: () => openConversation(contact.id) },
                        react_1.default.createElement("div", { className: "module-contact-modal__bubble-icon" },
                            react_1.default.createElement("div", { className: "module-contact-modal__send-message__bubble-icon" })),
                        react_1.default.createElement("span", null, i18n('ContactModal--message'))),
                    !contact.isMe && (react_1.default.createElement("button", { type: "button", className: "module-contact-modal__button module-contact-modal__safety-number", onClick: () => showSafetyNumber(contact.id) },
                        react_1.default.createElement("div", { className: "module-contact-modal__bubble-icon" },
                            react_1.default.createElement("div", { className: "module-contact-modal__safety-number__bubble-icon" })),
                        react_1.default.createElement("span", null, i18n('showSafetyNumber')))),
                    !contact.isMe && areWeAdmin && isMember && (react_1.default.createElement(react_1.default.Fragment, null,
                        react_1.default.createElement("button", { type: "button", className: "module-contact-modal__button module-contact-modal__make-admin", onClick: () => toggleAdmin(contact.id) },
                            react_1.default.createElement("div", { className: "module-contact-modal__bubble-icon" },
                                react_1.default.createElement("div", { className: "module-contact-modal__make-admin__bubble-icon" })),
                            isAdmin ? (react_1.default.createElement("span", null, i18n('ContactModal--rm-admin'))) : (react_1.default.createElement("span", null, i18n('ContactModal--make-admin')))),
                        react_1.default.createElement("button", { type: "button", className: "module-contact-modal__button module-contact-modal__remove-from-group", onClick: () => removeMember(contact.id) },
                            react_1.default.createElement("div", { className: "module-contact-modal__bubble-icon" },
                                react_1.default.createElement("div", { className: "module-contact-modal__remove-from-group__bubble-icon" })),
                            react_1.default.createElement("span", null, i18n('ContactModal--remove-from-group')))))))), root)
        : null;
};
exports.ContactModal = ContactModal;
