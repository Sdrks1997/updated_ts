"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const react_1 = require("@storybook/react");
const addon_actions_1 = require("@storybook/addon-actions");
const EmojiPicker_1 = require("../emoji/EmojiPicker");
const i18n_1 = require("../../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../../_locales/en/messages.json"));
const TimelineItem_1 = require("./TimelineItem");
const UniversalTimerNotification_1 = require("./UniversalTimerNotification");
const Calling_1 = require("../../types/Calling");
const getDefaultConversation_1 = require("../../test-both/helpers/getDefaultConversation");
const i18n = i18n_1.setup('en', messages_json_1.default);
const renderEmojiPicker = ({ onClose, onPickEmoji, ref, }) => (React.createElement(EmojiPicker_1.EmojiPicker, { i18n: i18n_1.setup('en', messages_json_1.default), skinTone: 0, onSetSkinTone: addon_actions_1.action('EmojiPicker::onSetSkinTone'), ref: ref, onClose: onClose, onPickEmoji: onPickEmoji }));
const renderContact = (conversationId) => (React.createElement(React.Fragment, { key: conversationId }, conversationId));
const renderUniversalTimerNotification = () => (React.createElement(UniversalTimerNotification_1.UniversalTimerNotification, { i18n: i18n, expireTimer: 3600 }));
const getDefaultProps = () => ({
    conversationId: 'conversation-id',
    conversationAccepted: true,
    id: 'asdf',
    isSelected: false,
    interactionMode: 'keyboard',
    selectMessage: addon_actions_1.action('selectMessage'),
    reactToMessage: addon_actions_1.action('reactToMessage'),
    checkForAccount: addon_actions_1.action('checkForAccount'),
    clearSelectedMessage: addon_actions_1.action('clearSelectedMessage'),
    contactSupport: addon_actions_1.action('contactSupport'),
    replyToMessage: addon_actions_1.action('replyToMessage'),
    retrySend: addon_actions_1.action('retrySend'),
    deleteMessage: addon_actions_1.action('deleteMessage'),
    deleteMessageForEveryone: addon_actions_1.action('deleteMessageForEveryone'),
    kickOffAttachmentDownload: addon_actions_1.action('kickOffAttachmentDownload'),
    markAttachmentAsCorrupted: addon_actions_1.action('markAttachmentAsCorrupted'),
    showMessageDetail: addon_actions_1.action('showMessageDetail'),
    openConversation: addon_actions_1.action('openConversation'),
    showContactDetail: addon_actions_1.action('showContactDetail'),
    showContactModal: addon_actions_1.action('showContactModal'),
    showForwardMessageModal: addon_actions_1.action('showForwardMessageModal'),
    showVisualAttachment: addon_actions_1.action('showVisualAttachment'),
    downloadAttachment: addon_actions_1.action('downloadAttachment'),
    displayTapToViewMessage: addon_actions_1.action('displayTapToViewMessage'),
    doubleCheckMissingQuoteReference: addon_actions_1.action('doubleCheckMissingQuoteReference'),
    showExpiredIncomingTapToViewToast: addon_actions_1.action('showExpiredIncomingTapToViewToast'),
    showExpiredOutgoingTapToViewToast: addon_actions_1.action('showExpiredIncomingTapToViewToast'),
    onHeightChange: addon_actions_1.action('onHeightChange'),
    openLink: addon_actions_1.action('openLink'),
    scrollToQuotedMessage: addon_actions_1.action('scrollToQuotedMessage'),
    downloadNewVersion: addon_actions_1.action('downloadNewVersion'),
    showIdentity: addon_actions_1.action('showIdentity'),
    messageSizeChanged: addon_actions_1.action('messageSizeChanged'),
    startCallingLobby: addon_actions_1.action('startCallingLobby'),
    returnToActiveCall: addon_actions_1.action('returnToActiveCall'),
    renderContact,
    renderUniversalTimerNotification,
    renderEmojiPicker,
    renderAudioAttachment: () => React.createElement("div", null, "*AudioAttachment*"),
});
react_1.storiesOf('Components/Conversation/TimelineItem', module)
    .add('Plain Message', () => {
    const item = {
        type: 'message',
        data: {
            id: 'id-1',
            direction: 'incoming',
            timestamp: Date.now(),
            author: {
                phoneNumber: '(202) 555-2001',
                color: 'forest',
            },
            text: '🔥',
        },
    };
    return React.createElement(TimelineItem_1.TimelineItem, Object.assign({}, getDefaultProps(), { item: item, i18n: i18n }));
})
    .add('Notification', () => {
    const items = [
        {
            type: 'timerNotification',
            data: Object.assign(Object.assign({ phoneNumber: '(202) 555-0000', expireTimer: 60 }, getDefaultConversation_1.getDefaultConversation()), { type: 'fromOther' }),
        },
        {
            type: 'chatSessionRefreshed',
        },
        {
            type: 'deliveryIssue',
            data: {
                sender: getDefaultConversation_1.getDefaultConversation(),
            },
        },
        {
            type: 'universalTimerNotification',
            data: null,
        },
        {
            type: 'callHistory',
            data: {
                // declined incoming audio
                callMode: Calling_1.CallMode.Direct,
                wasDeclined: true,
                wasIncoming: true,
                wasVideoCall: false,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // declined incoming video
                callMode: Calling_1.CallMode.Direct,
                wasDeclined: true,
                wasIncoming: true,
                wasVideoCall: true,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // accepted incoming audio
                callMode: Calling_1.CallMode.Direct,
                acceptedTime: Date.now() - 300,
                wasDeclined: false,
                wasIncoming: true,
                wasVideoCall: false,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // accepted incoming video
                callMode: Calling_1.CallMode.Direct,
                acceptedTime: Date.now() - 400,
                wasDeclined: false,
                wasIncoming: true,
                wasVideoCall: true,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // missed (neither accepted nor declined) incoming audio
                callMode: Calling_1.CallMode.Direct,
                wasDeclined: false,
                wasIncoming: true,
                wasVideoCall: false,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // missed (neither accepted nor declined) incoming video
                callMode: Calling_1.CallMode.Direct,
                wasDeclined: false,
                wasIncoming: true,
                wasVideoCall: true,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // accepted outgoing audio
                callMode: Calling_1.CallMode.Direct,
                acceptedTime: Date.now() - 200,
                wasDeclined: false,
                wasIncoming: false,
                wasVideoCall: false,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // accepted outgoing video
                callMode: Calling_1.CallMode.Direct,
                acceptedTime: Date.now() - 200,
                wasDeclined: false,
                wasIncoming: false,
                wasVideoCall: true,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // declined outgoing audio
                callMode: Calling_1.CallMode.Direct,
                wasDeclined: true,
                wasIncoming: false,
                wasVideoCall: false,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // declined outgoing video
                callMode: Calling_1.CallMode.Direct,
                wasDeclined: true,
                wasIncoming: false,
                wasVideoCall: true,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // missed (neither accepted nor declined) outgoing audio
                callMode: Calling_1.CallMode.Direct,
                wasDeclined: false,
                wasIncoming: false,
                wasVideoCall: false,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // missed (neither accepted nor declined) outgoing video
                callMode: Calling_1.CallMode.Direct,
                wasDeclined: false,
                wasIncoming: false,
                wasVideoCall: true,
                endedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // ongoing group call
                callMode: Calling_1.CallMode.Group,
                conversationId: 'abc123',
                creator: {
                    firstName: 'Luigi',
                    isMe: false,
                    title: 'Luigi Mario',
                },
                ended: false,
                deviceCount: 1,
                maxDevices: 16,
                startedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // ongoing group call started by you
                callMode: Calling_1.CallMode.Group,
                conversationId: 'abc123',
                creator: {
                    firstName: 'Peach',
                    isMe: true,
                    title: 'Princess Peach',
                },
                ended: false,
                deviceCount: 1,
                maxDevices: 16,
                startedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // ongoing group call, creator unknown
                callMode: Calling_1.CallMode.Group,
                conversationId: 'abc123',
                ended: false,
                deviceCount: 1,
                maxDevices: 16,
                startedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // ongoing and active group call
                callMode: Calling_1.CallMode.Group,
                activeCallConversationId: 'abc123',
                conversationId: 'abc123',
                creator: {
                    firstName: 'Luigi',
                    isMe: false,
                    title: 'Luigi Mario',
                },
                ended: false,
                deviceCount: 1,
                maxDevices: 16,
                startedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // ongoing group call, but you're in another one
                callMode: Calling_1.CallMode.Group,
                activeCallConversationId: 'abc123',
                conversationId: 'xyz987',
                creator: {
                    firstName: 'Luigi',
                    isMe: false,
                    title: 'Luigi Mario',
                },
                ended: false,
                deviceCount: 1,
                maxDevices: 16,
                startedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // ongoing full group call
                callMode: Calling_1.CallMode.Group,
                conversationId: 'abc123',
                creator: {
                    firstName: 'Luigi',
                    isMe: false,
                    title: 'Luigi Mario',
                },
                ended: false,
                deviceCount: 16,
                maxDevices: 16,
                startedTime: Date.now(),
            },
        },
        {
            type: 'callHistory',
            data: {
                // finished call
                callMode: Calling_1.CallMode.Group,
                conversationId: 'abc123',
                creator: {
                    firstName: 'Luigi',
                    isMe: false,
                    title: 'Luigi Mario',
                },
                ended: true,
                deviceCount: 0,
                maxDevices: 16,
                startedTime: Date.now(),
            },
        },
    ];
    return (React.createElement(React.Fragment, null, items.map((item, index) => (React.createElement(React.Fragment, { key: index },
        React.createElement(TimelineItem_1.TimelineItem, Object.assign({}, getDefaultProps(), { item: item, i18n: i18n })))))));
})
    .add('Unknown Type', () => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore: intentional
    const item = {
        type: 'random',
        data: {
            somethin: 'somethin',
        },
    };
    return React.createElement(TimelineItem_1.TimelineItem, Object.assign({}, getDefaultProps(), { item: item, i18n: i18n }));
})
    .add('Missing Item', () => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore: intentional
    const item = null;
    return React.createElement(TimelineItem_1.TimelineItem, Object.assign({}, getDefaultProps(), { item: item, i18n: i18n }));
});
