"use strict";
// Copyright 2018-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TypingBubble = void 0;
const react_1 = __importDefault(require("react"));
const classnames_1 = __importDefault(require("classnames"));
const TypingAnimation_1 = require("./TypingAnimation");
const Avatar_1 = require("../Avatar");
class TypingBubble extends react_1.default.PureComponent {
    renderAvatar() {
        const { acceptedMessageRequest, avatarPath, color, conversationType, i18n, isMe, name, phoneNumber, profileName, sharedGroupNames, title, } = this.props;
        if (conversationType !== 'group') {
            return null;
        }
        return (react_1.default.createElement("div", { className: "module-message__author-avatar-container" },
            react_1.default.createElement(Avatar_1.Avatar, { acceptedMessageRequest: acceptedMessageRequest, avatarPath: avatarPath, color: color, conversationType: "direct", i18n: i18n, isMe: isMe, name: name, phoneNumber: phoneNumber, profileName: profileName, title: title, sharedGroupNames: sharedGroupNames, size: 28 })));
    }
    render() {
        const { i18n, conversationType } = this.props;
        const isGroup = conversationType === 'group';
        return (react_1.default.createElement("div", { className: classnames_1.default('module-message', 'module-message--incoming', isGroup ? 'module-message--group' : null) },
            this.renderAvatar(),
            react_1.default.createElement("div", { className: "module-message__container-outer" },
                react_1.default.createElement("div", { className: classnames_1.default('module-message__container', 'module-message__container--incoming') },
                    react_1.default.createElement("div", { className: "module-message__typing-container" },
                        react_1.default.createElement(TypingAnimation_1.TypingAnimation, { color: "light", i18n: i18n }))))));
    }
}
exports.TypingBubble = TypingBubble;
