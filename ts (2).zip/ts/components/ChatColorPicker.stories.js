"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importDefault(require("react"));
const react_2 = require("@storybook/react");
const addon_actions_1 = require("@storybook/addon-actions");
const addon_knobs_1 = require("@storybook/addon-knobs");
const messages_json_1 = __importDefault(require("../../_locales/en/messages.json"));
const ChatColorPicker_1 = require("./ChatColorPicker");
const Colors_1 = require("../types/Colors");
const i18n_1 = require("../../js/modules/i18n");
const story = react_2.storiesOf('Components/ChatColorPicker', module);
const i18n = i18n_1.setup('en', messages_json_1.default);
const SAMPLE_CUSTOM_COLOR = {
    deg: 90,
    end: { hue: 197, saturation: 100 },
    start: { hue: 315, saturation: 78 },
};
const createProps = () => ({
    addCustomColor: addon_actions_1.action('addCustomColor'),
    colorSelected: addon_actions_1.action('colorSelected'),
    editCustomColor: addon_actions_1.action('editCustomColor'),
    getConversationsWithCustomColor: (_) => [],
    i18n,
    removeCustomColor: addon_actions_1.action('removeCustomColor'),
    removeCustomColorOnConversations: addon_actions_1.action('removeCustomColorOnConversations'),
    resetAllChatColors: addon_actions_1.action('resetAllChatColors'),
    resetDefaultChatColor: addon_actions_1.action('resetDefaultChatColor'),
    selectedColor: addon_knobs_1.select('selectedColor', Colors_1.ConversationColors, 'basil'),
    selectedCustomColor: {},
    setGlobalDefaultConversationColor: addon_actions_1.action('setGlobalDefaultConversationColor'),
});
story.add('Default', () => react_1.default.createElement(ChatColorPicker_1.ChatColorPicker, Object.assign({}, createProps())));
const CUSTOM_COLORS = {
    abc: {
        start: { hue: 32, saturation: 100 },
    },
    def: {
        deg: 90,
        start: { hue: 180, saturation: 100 },
        end: { hue: 0, saturation: 100 },
    },
    ghi: SAMPLE_CUSTOM_COLOR,
    jkl: {
        deg: 90,
        start: { hue: 161, saturation: 52 },
        end: { hue: 153, saturation: 89 },
    },
};
story.add('Custom Colors', () => (react_1.default.createElement(ChatColorPicker_1.ChatColorPicker, Object.assign({}, createProps(), { customColors: CUSTOM_COLORS, selectedColor: "custom", selectedCustomColor: {
        id: 'ghi',
        value: SAMPLE_CUSTOM_COLOR,
    } }))));
