"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importDefault(require("react"));
const lodash_1 = require("lodash");
const react_2 = require("@storybook/react");
const addon_actions_1 = require("@storybook/addon-actions");
const addon_knobs_1 = require("@storybook/addon-knobs");
const ConversationList_1 = require("./ConversationList");
const MessageSearchResult_1 = require("./conversationList/MessageSearchResult");
const ConversationListItem_1 = require("./conversationList/ConversationListItem");
const ContactCheckbox_1 = require("./conversationList/ContactCheckbox");
const getDefaultConversation_1 = require("../test-both/helpers/getDefaultConversation");
const i18n_1 = require("../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../_locales/en/messages.json"));
const i18n = i18n_1.setup('en', messages_json_1.default);
const story = react_2.storiesOf('Components/ConversationList', module);
const defaultConversations = [
    getDefaultConversation_1.getDefaultConversation({
        id: 'fred-convo',
        title: 'Fred Willard',
    }),
    getDefaultConversation_1.getDefaultConversation({
        id: 'marc-convo',
        isSelected: true,
        unreadCount: 12,
        title: 'Marc Barraca',
    }),
    getDefaultConversation_1.getDefaultConversation({
        id: 'long-name-convo',
        title: 'Pablo Diego José Francisco de Paula Juan Nepomuceno María de los Remedios Cipriano de la Santísima Trinidad Ruiz y Picasso',
    }),
    getDefaultConversation_1.getDefaultConversation(),
];
const createProps = (rows) => ({
    dimensions: {
        width: 300,
        height: 350,
    },
    rowCount: rows.length,
    getRow: (index) => rows[index],
    shouldRecomputeRowHeights: false,
    i18n,
    onSelectConversation: addon_actions_1.action('onSelectConversation'),
    onClickArchiveButton: addon_actions_1.action('onClickArchiveButton'),
    onClickContactCheckbox: addon_actions_1.action('onClickContactCheckbox'),
    renderMessageSearchResult: (id, style) => (react_1.default.createElement(MessageSearchResult_1.MessageSearchResult, { body: "Lorem ipsum wow", bodyRanges: [], conversationId: "marc-convo", from: defaultConversations[0], i18n: i18n, id: id, openConversationInternal: addon_actions_1.action('openConversationInternal'), sentAt: 1587358800000, snippet: "Lorem <<left>>ipsum<<right>> wow", style: style, to: defaultConversations[1] })),
    showChooseGroupMembers: addon_actions_1.action('showChooseGroupMembers'),
    startNewConversationFromPhoneNumber: addon_actions_1.action('startNewConversationFromPhoneNumber'),
});
story.add('Archive button', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
    {
        type: ConversationList_1.RowType.ArchiveButton,
        archivedConversationsCount: 123,
    },
])))));
story.add('Contact: note to self', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
    {
        type: ConversationList_1.RowType.Contact,
        contact: Object.assign(Object.assign({}, defaultConversations[0]), { isMe: true, about: '🤠 should be ignored' }),
    },
])))));
story.add('Contact: direct', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
    {
        type: ConversationList_1.RowType.Contact,
        contact: defaultConversations[0],
    },
])))));
story.add('Contact: direct with short about', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
    {
        type: ConversationList_1.RowType.Contact,
        contact: Object.assign(Object.assign({}, defaultConversations[0]), { about: '🤠 yee haw' }),
    },
])))));
story.add('Contact: direct with long about', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
    {
        type: ConversationList_1.RowType.Contact,
        contact: Object.assign(Object.assign({}, defaultConversations[0]), { about: '🤠 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit. Donec et mollis dolor. Praesent et diam eget libero egestas mattis sit amet vitae augue.' }),
    },
])))));
story.add('Contact: group', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
    {
        type: ConversationList_1.RowType.Contact,
        contact: Object.assign(Object.assign({}, defaultConversations[0]), { type: 'group' }),
    },
])))));
story.add('Contact checkboxes', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
    {
        type: ConversationList_1.RowType.ContactCheckbox,
        contact: defaultConversations[0],
        isChecked: true,
    },
    {
        type: ConversationList_1.RowType.ContactCheckbox,
        contact: defaultConversations[1],
        isChecked: false,
    },
    {
        type: ConversationList_1.RowType.ContactCheckbox,
        contact: Object.assign(Object.assign({}, defaultConversations[2]), { about: '😃 Hola' }),
        isChecked: true,
    },
])))));
story.add('Contact checkboxes: disabled', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
    {
        type: ConversationList_1.RowType.ContactCheckbox,
        contact: defaultConversations[0],
        isChecked: false,
        disabledReason: ContactCheckbox_1.ContactCheckboxDisabledReason.MaximumContactsSelected,
    },
    {
        type: ConversationList_1.RowType.ContactCheckbox,
        contact: defaultConversations[1],
        isChecked: false,
        disabledReason: ContactCheckbox_1.ContactCheckboxDisabledReason.NotCapable,
    },
    {
        type: ConversationList_1.RowType.ContactCheckbox,
        contact: defaultConversations[2],
        isChecked: true,
        disabledReason: ContactCheckbox_1.ContactCheckboxDisabledReason.MaximumContactsSelected,
    },
    {
        type: ConversationList_1.RowType.ContactCheckbox,
        contact: defaultConversations[3],
        isChecked: true,
        disabledReason: ContactCheckbox_1.ContactCheckboxDisabledReason.AlreadyAdded,
    },
])))));
{
    const createConversation = (overrideProps = {}) => (Object.assign(Object.assign({}, overrideProps), { acceptedMessageRequest: addon_knobs_1.boolean('acceptedMessageRequest', overrideProps.acceptedMessageRequest !== undefined
            ? overrideProps.acceptedMessageRequest
            : true), isMe: addon_knobs_1.boolean('isMe', overrideProps.isMe || false), avatarPath: addon_knobs_1.text('avatarPath', overrideProps.avatarPath || ''), id: overrideProps.id || '', isSelected: addon_knobs_1.boolean('isSelected', overrideProps.isSelected || false), title: addon_knobs_1.text('title', overrideProps.title || 'Some Person'), name: overrideProps.name || 'Some Person', type: overrideProps.type || 'direct', markedUnread: addon_knobs_1.boolean('markedUnread', overrideProps.markedUnread || false), lastMessage: overrideProps.lastMessage || {
            text: addon_knobs_1.text('lastMessage.text', 'Hi there!'),
            status: addon_knobs_1.select('status', ConversationListItem_1.MessageStatuses.reduce((m, s) => (Object.assign(Object.assign({}, m), { [s]: s })), {}), 'read'),
        }, lastUpdated: addon_knobs_1.date('lastUpdated', new Date(overrideProps.lastUpdated || Date.now() - 5 * 60 * 1000)), sharedGroupNames: [] }));
    const renderConversation = (overrideProps = {}) => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
        {
            type: ConversationList_1.RowType.Conversation,
            conversation: createConversation(overrideProps),
        },
    ]))));
    story.add('Conversation: name', () => renderConversation());
    story.add('Conversation: name and avatar', () => renderConversation({
        avatarPath: '/fixtures/kitten-1-64-64.jpg',
    }));
    story.add('Conversation: with yourself', () => renderConversation({
        lastMessage: {
            text: 'Just a second',
            status: 'read',
        },
        name: 'Myself',
        title: 'Myself',
        isMe: true,
    }));
    story.add('Conversations: Message Statuses', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps(ConversationListItem_1.MessageStatuses.map(status => ({
        type: ConversationList_1.RowType.Conversation,
        conversation: createConversation({
            lastMessage: { text: status, status },
        }),
    })))))));
    story.add('Conversation: Typing Status', () => renderConversation({
        typingContact: {
            name: 'Someone Here',
        },
    }));
    story.add('Conversation: With draft', () => renderConversation({
        shouldShowDraft: true,
        draftPreview: "I'm in the middle of typing this...",
    }));
    story.add('Conversation: Deleted for everyone', () => renderConversation({
        lastMessage: {
            status: 'sent',
            text: 'You should not see this!',
            deletedForEveryone: true,
        },
    }));
    story.add('Conversation: Message Request', () => renderConversation({
        acceptedMessageRequest: false,
        lastMessage: {
            text: 'A Message',
            status: 'delivered',
        },
    }));
    story.add('Conversations: unread count', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([4, 10, 250].map(unreadCount => ({
        type: ConversationList_1.RowType.Conversation,
        conversation: createConversation({
            lastMessage: { text: 'Hey there!', status: 'delivered' },
            unreadCount,
        }),
    })))))));
    story.add('Conversation: marked unread', () => renderConversation({ markedUnread: true }));
    story.add('Conversation: Selected', () => renderConversation({
        lastMessage: {
            text: 'Hey there!',
            status: 'read',
        },
        isSelected: true,
    }));
    story.add('Conversation: Emoji in Message', () => renderConversation({
        lastMessage: {
            text: '🔥',
            status: 'read',
        },
    }));
    story.add('Conversation: Link in Message', () => renderConversation({
        lastMessage: {
            text: 'Download at http://signal.org',
            status: 'read',
        },
    }));
    story.add('Conversation: long name', () => {
        const name = 'Long contact name. Esquire. The third. And stuff. And more! And more!';
        return renderConversation({
            name,
            title: name,
        });
    });
    story.add('Conversation: Long Message', () => {
        const messages = [
            "Long line. This is a really really really long line. Really really long. Because that's just how it is",
            `Many lines. This is a many-line message.
Line 2 is really exciting but it shouldn't be seen.
Line three is even better.
Line 4, well.`,
        ];
        return (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps(messages.map(messageText => ({
            type: ConversationList_1.RowType.Conversation,
            conversation: createConversation({
                lastMessage: {
                    text: messageText,
                    status: 'read',
                },
            }),
        }))))));
    });
    story.add('Conversations: Various Times', () => {
        const pairs = [
            [Date.now() - 5 * 60 * 60 * 1000, 'Five hours ago'],
            [Date.now() - 24 * 60 * 60 * 1000, 'One day ago'],
            [Date.now() - 7 * 24 * 60 * 60 * 1000, 'One week ago'],
            [Date.now() - 365 * 24 * 60 * 60 * 1000, 'One year ago'],
        ];
        return (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps(pairs.map(([lastUpdated, messageText]) => ({
            type: ConversationList_1.RowType.Conversation,
            conversation: createConversation({
                lastUpdated,
                lastMessage: {
                    text: messageText,
                    status: 'read',
                },
            }),
        }))))));
    });
    story.add('Conversation: Missing Date', () => {
        const row = {
            type: ConversationList_1.RowType.Conversation,
            conversation: lodash_1.omit(createConversation(), 'lastUpdated'),
        };
        return react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([row])));
    });
    story.add('Conversation: Missing Message', () => {
        const row = {
            type: ConversationList_1.RowType.Conversation,
            conversation: lodash_1.omit(createConversation(), 'lastMessage'),
        };
        return react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([row])));
    });
    story.add('Conversation: Missing Text', () => renderConversation({
        lastMessage: {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            text: undefined,
            status: 'sent',
        },
    }));
    story.add('Conversation: Muted Conversation', () => renderConversation({
        muteExpiresAt: Date.now() + 1000 * 60 * 60,
    }));
    story.add('Conversation: At Mention', () => renderConversation({
        title: 'The Rebellion',
        type: 'group',
        lastMessage: {
            text: '@Leia Organa I know',
            status: 'read',
        },
    }));
}
story.add('Headers', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
    {
        type: ConversationList_1.RowType.Header,
        i18nKey: 'conversationsHeader',
    },
    {
        type: ConversationList_1.RowType.Header,
        i18nKey: 'messagesHeader',
    },
])))));
story.add('Start new conversation', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
    {
        type: ConversationList_1.RowType.StartNewConversation,
        phoneNumber: '+12345559876',
    },
])))));
story.add('Search results loading skeleton', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({ scrollable: false }, createProps([
    { type: ConversationList_1.RowType.SearchResultsLoadingFakeHeader },
    ...lodash_1.times(99, () => ({
        type: ConversationList_1.RowType.SearchResultsLoadingFakeRow,
    })),
])))));
story.add('Kitchen sink', () => (react_1.default.createElement(ConversationList_1.ConversationList, Object.assign({}, createProps([
    {
        type: ConversationList_1.RowType.StartNewConversation,
        phoneNumber: '+12345559876',
    },
    {
        type: ConversationList_1.RowType.Header,
        i18nKey: 'messagesHeader',
    },
    {
        type: ConversationList_1.RowType.Contact,
        contact: defaultConversations[0],
    },
    {
        type: ConversationList_1.RowType.Conversation,
        conversation: defaultConversations[1],
    },
    {
        type: ConversationList_1.RowType.MessageSearchResult,
        messageId: '123',
    },
    {
        type: ConversationList_1.RowType.ArchiveButton,
        archivedConversationsCount: 123,
    },
])))));
