"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarInput = exports.AvatarInputVariant = void 0;
const react_1 = __importStar(require("react"));
const classnames_1 = __importDefault(require("classnames"));
const react_contextmenu_1 = require("react-contextmenu");
const blueimp_load_image_1 = __importDefault(require("blueimp-load-image"));
const lodash_1 = require("lodash");
const Spinner_1 = require("./Spinner");
const canvasToArrayBuffer_1 = require("../util/canvasToArrayBuffer");
var ImageStatus;
(function (ImageStatus) {
    ImageStatus["Nothing"] = "nothing";
    ImageStatus["Loading"] = "loading";
    ImageStatus["HasImage"] = "has-image";
})(ImageStatus || (ImageStatus = {}));
var AvatarInputVariant;
(function (AvatarInputVariant) {
    AvatarInputVariant["Light"] = "light";
    AvatarInputVariant["Dark"] = "dark";
})(AvatarInputVariant = exports.AvatarInputVariant || (exports.AvatarInputVariant = {}));
const AvatarInput = ({ contextMenuId, disabled, i18n, onChange, value, variant = AvatarInputVariant.Light, }) => {
    const fileInputRef = react_1.useRef(null);
    // Comes from a third-party dependency
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const menuTriggerRef = react_1.useRef(null);
    const [objectUrl, setObjectUrl] = react_1.useState();
    react_1.useEffect(() => {
        if (!value) {
            setObjectUrl(undefined);
            return lodash_1.noop;
        }
        const url = URL.createObjectURL(new Blob([value]));
        setObjectUrl(url);
        return () => {
            URL.revokeObjectURL(url);
        };
    }, [value]);
    const [processingFile, setProcessingFile] = react_1.useState(undefined);
    react_1.useEffect(() => {
        if (!processingFile) {
            return lodash_1.noop;
        }
        let shouldCancel = false;
        (async () => {
            let newValue;
            try {
                newValue = await processFile(processingFile);
            }
            catch (err) {
                // Processing errors should be rare; if they do, we silently fail. In an ideal
                //   world, we may want to show a toast instead.
                return;
            }
            if (shouldCancel) {
                return;
            }
            setProcessingFile(undefined);
            onChange(newValue);
        })();
        return () => {
            shouldCancel = true;
        };
    }, [processingFile, onChange]);
    const buttonLabel = value
        ? i18n('AvatarInput--change-photo-label')
        : i18n('AvatarInput--no-photo-label--group');
    const startUpload = () => {
        const fileInput = fileInputRef.current;
        if (fileInput) {
            fileInput.click();
        }
    };
    const clear = () => {
        onChange(undefined);
    };
    const onClick = value
        ? event => {
            const menuTrigger = menuTriggerRef.current;
            if (!menuTrigger) {
                return;
            }
            menuTrigger.handleContextClick(event);
        }
        : startUpload;
    const onInputChange = event => {
        const file = event.target.files && event.target.files[0];
        if (file) {
            setProcessingFile(file);
        }
    };
    let imageStatus;
    if (processingFile || (value && !objectUrl)) {
        imageStatus = ImageStatus.Loading;
    }
    else if (objectUrl) {
        imageStatus = ImageStatus.HasImage;
    }
    else {
        imageStatus = ImageStatus.Nothing;
    }
    const isLoading = imageStatus === ImageStatus.Loading;
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(react_contextmenu_1.ContextMenuTrigger, { id: contextMenuId, ref: menuTriggerRef },
            react_1.default.createElement("button", { type: "button", disabled: disabled || isLoading, className: classnames_1.default('module-AvatarInput', `module-AvatarInput--${variant}`), onClick: onClick },
                react_1.default.createElement("div", { className: `module-AvatarInput__avatar module-AvatarInput__avatar--${imageStatus}`, style: imageStatus === ImageStatus.HasImage
                        ? {
                            backgroundImage: `url(${objectUrl})`,
                        }
                        : undefined }, isLoading && (react_1.default.createElement(Spinner_1.Spinner, { size: "70px", svgSize: "normal", direction: "on-avatar" }))),
                react_1.default.createElement("span", { className: "module-AvatarInput__label" }, buttonLabel))),
        react_1.default.createElement(react_contextmenu_1.ContextMenu, { id: contextMenuId },
            react_1.default.createElement(react_contextmenu_1.MenuItem, { onClick: startUpload }, i18n('AvatarInput--upload-photo-choice')),
            react_1.default.createElement(react_contextmenu_1.MenuItem, { onClick: clear }, i18n('AvatarInput--remove-photo-choice'))),
        react_1.default.createElement("input", { accept: ".gif,.jpg,.jpeg,.png,.webp,image/gif,image/jpeg/image/png,image/webp", hidden: true, onChange: onInputChange, ref: fileInputRef, type: "file" })));
};
exports.AvatarInput = AvatarInput;
async function processFile(file) {
    const { image } = await blueimp_load_image_1.default(file, {
        canvas: true,
        cover: true,
        crop: true,
        imageSmoothingQuality: 'medium',
        maxHeight: 512,
        maxWidth: 512,
        minHeight: 2,
        minWidth: 2,
    });
    // NOTE: The types for `loadImage` say this can never be a canvas, but it will be if
    //   `canvas: true`, at least in our case. Again, updating DefinitelyTyped should
    //   address this.
    if (!(image instanceof HTMLCanvasElement)) {
        throw new Error('Loaded image was not a canvas');
    }
    return canvasToArrayBuffer_1.canvasToArrayBuffer(image);
}
